"""Bidirectional drug-target cross attention."""

# NEW MODULE

from __future__ import annotations

import torch
import torch.nn as nn


def masked_mean(tokens: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    weights = mask.unsqueeze(-1).to(tokens.dtype)
    return (tokens * weights).sum(1) / weights.sum(1).clamp_min(1.0)


class MutualAttention(nn.Module):
    """Atom-to-residue and residue-to-atom attention returning an interaction vector."""

    def __init__(self, hidden_dim: int = 256, num_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.drug_to_target = nn.MultiheadAttention(hidden_dim, num_heads, dropout=dropout, batch_first=True)
        self.target_to_drug = nn.MultiheadAttention(hidden_dim, num_heads, dropout=dropout, batch_first=True)
        self.norm_d = nn.LayerNorm(hidden_dim)
        self.norm_t = nn.LayerNorm(hidden_dim)
        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim * 2), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim), nn.LayerNorm(hidden_dim),
        )

    def forward(self, drug_tokens, target_tokens, drug_mask=None, target_mask=None):
        if drug_mask is None:
            drug_mask = torch.ones(drug_tokens.shape[:2], dtype=torch.bool, device=drug_tokens.device)
        if target_mask is None:
            target_mask = torch.ones(target_tokens.shape[:2], dtype=torch.bool, device=target_tokens.device)
        d_context, d_weights = self.drug_to_target(
            drug_tokens, target_tokens, target_tokens, key_padding_mask=~target_mask,
            need_weights=True, average_attn_weights=False,
        )
        t_context, t_weights = self.target_to_drug(
            target_tokens, drug_tokens, drug_tokens, key_padding_mask=~drug_mask,
            need_weights=True, average_attn_weights=False,
        )
        d_context = self.norm_d(drug_tokens + d_context)
        t_context = self.norm_t(target_tokens + t_context)
        d_pool, t_pool = masked_mean(d_context, drug_mask), masked_mean(t_context, target_mask)
        interaction = self.fusion(torch.cat((d_pool, t_pool, torch.abs(d_pool - t_pool), d_pool * t_pool), -1))
        return interaction, {"drug_to_target": d_weights, "target_to_drug": t_weights}
