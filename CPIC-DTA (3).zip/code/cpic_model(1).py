from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import DenseGCNConv, GCNConv, global_mean_pool
from torch_geometric.utils import dropout_adj


class DenseAffinityEncoder(nn.Module):
    def __init__(self, layers_dim, edge_dropout_rate=0.2):
        super().__init__()
        self.edge_dropout_rate = edge_dropout_rate
        self.convs = nn.ModuleList(
            DenseGCNConv(layers_dim[i], layers_dim[i + 1]) for i in range(len(layers_dim) - 1)
        )
        self.dropout = nn.Dropout(0.1)

    def forward(self, graph):
        x, adj = graph.x, graph.adj
        indices = torch.where(adj != 0)
        edge_index = torch.stack(indices, dim=0)
        edge_index_drop, edge_weight_drop = dropout_adj(
            edge_index=edge_index,
            edge_attr=adj[indices],
            p=self.edge_dropout_rate,
            force_undirected=True,
            num_nodes=x.size(0),
            training=self.training,
        )
        adj_drop = torch.zeros_like(adj)
        adj_drop[edge_index_drop[0], edge_index_drop[1]] = edge_weight_drop

        out = x
        for conv in self.convs:
            out = conv(out, adj_drop, add_loop=False)
            if out.dim() == 3:
                out = out.squeeze(0)
            out = self.dropout(F.relu(out))
        return out


class GraphTokenEncoder(nn.Module):
    def __init__(self, layers_dim, max_tokens):
        super().__init__()
        self.max_tokens = max_tokens
        self.convs = nn.ModuleList(GCNConv(layers_dim[i], layers_dim[i + 1]) for i in range(len(layers_dim) - 1))

    def forward(self, graph_batch):
        x, edge_index, batch = graph_batch.x, graph_batch.edge_index, graph_batch.batch
        out = x
        for conv in self.convs:
            out = F.relu(conv(out, edge_index))
        graph_emb = global_mean_pool(out, batch)
        token_tensor, token_mask = self._dense_tokens(out, batch, graph_emb.size(0), self.max_tokens)
        return graph_emb, token_tensor, token_mask

    @staticmethod
    def _dense_tokens(node_emb, batch, num_graphs, max_tokens):
        hidden_dim = node_emb.size(-1)
        tokens = node_emb.new_zeros((num_graphs, max_tokens, hidden_dim))
        mask = torch.zeros((num_graphs, max_tokens), dtype=torch.bool, device=node_emb.device)
        for graph_id in range(num_graphs):
            node_ids = torch.nonzero(batch == graph_id, as_tuple=False).view(-1)
            if node_ids.numel() == 0:
                continue
            node_ids = node_ids[:max_tokens]
            n = node_ids.numel()
            tokens[graph_id, :n] = node_emb[node_ids]
            mask[graph_id, :n] = True
        return tokens, mask


class ProjectionContrast(nn.Module):
    def __init__(self, hidden_dim, output_dim, tau, lam):
        super().__init__()
        self.proj = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.ELU(), nn.Linear(hidden_dim, output_dim))
        self.tau = tau
        self.lam = lam
        for layer in self.proj:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_normal_(layer.weight, gain=1.414)

    def _sim(self, z1, z2):
        z1 = F.normalize(z1, dim=-1)
        z2 = F.normalize(z2, dim=-1)
        return torch.exp(torch.mm(z1, z2.t()) / self.tau)

    def forward(self, relation_emb, graph_emb, pos):
        rel_proj = self.proj(relation_emb)
        graph_proj = self.proj(graph_emb)
        rel_to_graph = self._sim(rel_proj, graph_proj)
        graph_to_rel = rel_to_graph.t()
        pos_dense = pos.to_dense().to(rel_proj.device)

        rel_to_graph = rel_to_graph / (rel_to_graph.sum(dim=1, keepdim=True) + 1e-8)
        loss_rel = -torch.log((rel_to_graph * pos_dense).sum(dim=-1) + 1e-8).mean()

        graph_to_rel = graph_to_rel / (graph_to_rel.sum(dim=1, keepdim=True) + 1e-8)
        loss_graph = -torch.log((graph_to_rel * pos_dense).sum(dim=-1) + 1e-8).mean()

        entity_emb = torch.cat((rel_proj, graph_proj), dim=-1)
        return self.lam * loss_rel + (1.0 - self.lam) * loss_graph, entity_emb


class ImportantTokenSelector(nn.Module):
    """Learn atom importance and retain a small, differentiably weighted top-k set."""

    def __init__(self, token_dim=256, top_k=10):
        super().__init__()
        self.top_k = top_k
        self.score = nn.Sequential(
            nn.Linear(token_dim, token_dim // 2),
            nn.GELU(),
            nn.Linear(token_dim // 2, 1),
        )

    def forward(self, tokens, mask):
        scores = self.score(tokens).squeeze(-1).masked_fill(~mask, torch.finfo(tokens.dtype).min)
        k = min(self.top_k, tokens.size(1))
        top_scores, top_ids = scores.topk(k, dim=1)
        gather_ids = top_ids.unsqueeze(-1).expand(-1, -1, tokens.size(-1))
        selected = tokens.gather(1, gather_ids)
        selected_mask = mask.gather(1, top_ids)
        top_scores = top_scores.masked_fill(~selected_mask, torch.finfo(tokens.dtype).min)
        weights = torch.softmax(top_scores, dim=1).masked_fill(~selected_mask, 0.0)
        weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        weighted_tokens = selected * weights.unsqueeze(-1)
        representation = weighted_tokens.sum(dim=1)
        return selected, selected_mask, representation, scores


class AttentionPooling(nn.Module):
    """Learn residue importance instead of using unweighted mean pooling."""

    def __init__(self, token_dim=256):
        super().__init__()
        self.score = nn.Sequential(
            nn.Linear(token_dim, token_dim // 2),
            nn.Tanh(),
            nn.Linear(token_dim // 2, 1),
        )

    def forward(self, tokens, mask):
        scores = self.score(tokens).squeeze(-1).masked_fill(~mask, torch.finfo(tokens.dtype).min)
        weights = torch.softmax(scores, dim=1).masked_fill(~mask, 0.0)
        weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        return (tokens * weights.unsqueeze(-1)).sum(dim=1), weights


class PairInteractionHead(nn.Module):
    def __init__(self, entity_dim=256, token_dim=256, num_heads=4, dropout=0.1, drug_top_k=10):
        super().__init__()
        self.drug_selector = ImportantTokenSelector(token_dim, drug_top_k)
        self.protein_pool = AttentionPooling(token_dim)
        self.drug_to_target = nn.MultiheadAttention(token_dim, num_heads, dropout=dropout, batch_first=True)
        self.target_to_drug = nn.MultiheadAttention(token_dim, num_heads, dropout=dropout, batch_first=True)
        pair_dim = entity_dim * 4 + token_dim * 4
        self.pair_proj = nn.Sequential(
            nn.Linear(pair_dim, 512),
            nn.LayerNorm(512),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(512, 256),
            nn.GELU(),
        )
        self.reg_head = nn.Linear(256, 1)
        self.range_head = nn.Linear(256, 3)

    def forward(self, data, drug_entity, target_entity, drug_tokens, drug_mask, target_tokens, target_mask):
        drug_ids = data.drug_id.view(-1).long().to(drug_entity.device)
        target_ids = data.target_id.view(-1).long().to(target_entity.device)

        d_entity = drug_entity[drug_ids]
        t_entity = target_entity[target_ids]
        d_tokens = drug_tokens[drug_ids]
        t_tokens = target_tokens[target_ids]
        d_mask = drug_mask[drug_ids]
        t_mask = target_mask[target_ids]

        important_drug, important_mask, drug_substructure, atom_scores = self.drug_selector(d_tokens, d_mask)
        protein_binding, residue_weights = self.protein_pool(t_tokens, t_mask)

        # Atom-to-residue attention exposes the local interaction matrix.  The
        # reverse direction uses the pooled binding query to avoid materializing
        # a second [B, L, K] activation tensor.
        d_ctx_tokens, interaction_matrix = self.drug_to_target(
            important_drug,
            t_tokens,
            t_tokens,
            key_padding_mask=~t_mask,
            need_weights=True,
            average_attn_weights=False,
        )
        p_ctx_token, reverse_attention = self.target_to_drug(
            protein_binding.unsqueeze(1),
            important_drug,
            important_drug,
            key_padding_mask=~important_mask,
            need_weights=True,
            average_attn_weights=False,
        )
        d_ctx = masked_mean(d_ctx_tokens, important_mask)
        t_ctx = p_ctx_token.squeeze(1)

        pair_input = torch.cat(
            (
                d_entity,
                t_entity,
                torch.abs(d_entity - t_entity),
                d_entity * t_entity,
                d_ctx,
                t_ctx,
                drug_substructure,
                protein_binding,
            ),
            dim=-1,
        )
        pair_repr = self.pair_proj(pair_input)
        affinity = self.reg_head(pair_repr)
        range_logits = self.range_head(pair_repr)
        interaction_aux = {
            "interaction_matrix": interaction_matrix,
            "reverse_attention": reverse_attention,
            "atom_importance": atom_scores,
            "residue_importance": residue_weights,
            "drug_substructure": drug_substructure,
            "protein_binding": protein_binding,
        }
        return affinity, range_logits, pair_repr, interaction_aux


def masked_mean(tokens, mask):
    mask = mask.unsqueeze(-1).float()
    denom = mask.sum(dim=1).clamp_min(1.0)
    return (tokens * mask).sum(dim=1) / denom


class CPICDTA(nn.Module):
    def __init__(
        self,
        tau,
        lam,
        ns_dims,
        drug_dims,
        target_dims,
        embedding_dim=128,
        edge_dropout_rate=0.2,
        max_drug_tokens=128,
        max_target_tokens=512,
        pair_heads=4,
        pair_dropout=0.1,
        drug_top_k=10,
    ):
        super().__init__()
        self.affinity_encoder = DenseAffinityEncoder(ns_dims, edge_dropout_rate=edge_dropout_rate)
        self.drug_encoder = GraphTokenEncoder(drug_dims, max_tokens=max_drug_tokens)
        self.target_encoder = GraphTokenEncoder(target_dims, max_tokens=max_target_tokens)
        self.drug_contrast = ProjectionContrast(ns_dims[-1], embedding_dim, tau, lam)
        self.target_contrast = ProjectionContrast(ns_dims[-1], embedding_dim, tau, lam)
        self.max_target_tokens = max_target_tokens
        self.token_dim = target_dims[-1]
        self.register_buffer("esm_residue_tokens", torch.empty(0), persistent=False)
        self.register_buffer("esm_residue_mask", torch.empty(0, dtype=torch.bool), persistent=False)
        entity_dim = embedding_dim * 2
        self.pair_head = PairInteractionHead(
            entity_dim=entity_dim,
            token_dim=drug_dims[-1],
            num_heads=pair_heads,
            dropout=pair_dropout,
            drug_top_k=drug_top_k,
        )

    def load_precomputed_esm(self, cache_path, device):
        """Load residue-level ESM tokens once; forward never invokes ESM-2."""
        try:
            payload = torch.load(cache_path, map_location="cpu", weights_only=False)
        except TypeError:
            payload = torch.load(cache_path, map_location="cpu")
        tokens = payload["tokens"]
        mask = payload["mask"].bool()
        if tokens.dim() != 3 or mask.shape != tokens.shape[:2]:
            raise ValueError(f"Invalid ESM cache shapes: tokens={tokens.shape}, mask={mask.shape}")
        if tokens.size(-1) != self.token_dim:
            raise ValueError(
                f"ESM token dim {tokens.size(-1)} does not match CPIC token dim {self.token_dim}; "
                "precompute projected 256-dimensional tokens."
            )
        self.esm_residue_tokens = tokens[:, : self.max_target_tokens].to(device)
        self.esm_residue_mask = mask[:, : self.max_target_tokens].to(device)
        return payload

    def encode_entities(self, affinity_graph, drug_graph_batch, target_graph_batch, drug_pos, target_pos):
        num_drug = affinity_graph.num_drug
        relation_emb = self.affinity_encoder(affinity_graph)
        drug_graph_emb, drug_tokens, drug_mask = self.drug_encoder(drug_graph_batch)
        target_graph_emb, target_graph_tokens, target_graph_mask = self.target_encoder(target_graph_batch)
        if self.esm_residue_tokens.numel():
            if self.esm_residue_tokens.size(0) != target_graph_emb.size(0):
                raise ValueError(
                    f"ESM target count {self.esm_residue_tokens.size(0)} != graph target count {target_graph_emb.size(0)}"
                )
            target_tokens, target_mask = self.esm_residue_tokens, self.esm_residue_mask
        else:
            target_tokens, target_mask = target_graph_tokens, target_graph_mask

        drug_ssl, drug_entity = self.drug_contrast(relation_emb[:num_drug], drug_graph_emb, drug_pos)
        target_ssl, target_entity = self.target_contrast(relation_emb[num_drug:], target_graph_emb, target_pos)
        aux = {
            "ssl_loss": drug_ssl + target_ssl,
            "drug_relation_emb": relation_emb[:num_drug],
            "drug_graph_emb": drug_graph_emb,
            "target_relation_emb": relation_emb[num_drug:],
            "target_graph_emb": target_graph_emb,
        }
        return drug_entity, target_entity, drug_tokens, drug_mask, target_tokens, target_mask, aux

    def forward(self, data, affinity_graph, drug_graph_batch, target_graph_batch, drug_pos, target_pos):
        encoded = self.encode_entities(affinity_graph, drug_graph_batch, target_graph_batch, drug_pos, target_pos)
        drug_entity, target_entity, drug_tokens, drug_mask, target_tokens, target_mask, aux = encoded
        pred, range_logits, pair_repr, interaction_aux = self.pair_head(
            data,
            drug_entity,
            target_entity,
            drug_tokens,
            drug_mask,
            target_tokens,
            target_mask,
        )
        aux["pair_repr"] = pair_repr
        aux.update(interaction_aux)
        return pred, range_logits, aux


# NEW MODULE: projections for the multi-scale drug representation.
class DrugViewProjection(nn.Module):
    """Project one drug view to the shared 256-dimensional feature space."""

    def __init__(self, input_dim, output_dim=256):
        super().__init__()
        self.projection = nn.Sequential(
            nn.Linear(input_dim, output_dim),
            nn.LayerNorm(output_dim),
            nn.GELU(),
        )

    def forward(self, features):
        return self.projection(features)


class MorganFingerprintProjection(nn.Module):
    """Map a radius-2, 2048-bit Morgan vector to a 256-d embedding."""

    def __init__(self, input_dim=2048, output_dim=256, dropout=0.1):
        super().__init__()
        self.projection = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(512, output_dim),
            nn.LayerNorm(output_dim),
            nn.GELU(),
        )

    def forward(self, fingerprints):
        return self.projection(fingerprints)


class MultiscaleDrugPairInteractionHead(PairInteractionHead):
    """Original interaction head with a wider drug entity only.

    Protein entities and all token-level interaction modules remain unchanged.
    The 768-d drug entity is projected to 256-d only for |D-P| and D*P,
    while its complete representation is retained in the fusion input.
    """

    def __init__(
        self,
        drug_entity_dim=768,
        target_entity_dim=256,
        token_dim=256,
        num_heads=4,
        dropout=0.1,
        drug_top_k=10,
    ):
        super().__init__(
            entity_dim=target_entity_dim,
            token_dim=token_dim,
            num_heads=num_heads,
            dropout=dropout,
            drug_top_k=drug_top_k,
        )
        self.drug_entity_dim = int(drug_entity_dim)
        self.target_entity_dim = int(target_entity_dim)
        self.drug_compatibility_projection = nn.Sequential(
            nn.Linear(self.drug_entity_dim, self.target_entity_dim),
            nn.LayerNorm(self.target_entity_dim),
            nn.GELU(),
        )
        self.pair_input_dim = (
            self.drug_entity_dim
            + self.target_entity_dim
            + self.target_entity_dim * 2
            + token_dim * 4
        )
        self.pair_proj = nn.Sequential(
            nn.Linear(self.pair_input_dim, 512),
            nn.LayerNorm(512),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(512, 256),
        )
        # reg_head inherited unchanged: Linear(256, 1).

    def forward(self, data, drug_entity, target_entity, drug_tokens, drug_mask, target_tokens, target_mask):
        drug_ids = data.drug_id.view(-1).long().to(drug_entity.device)
        target_ids = data.target_id.view(-1).long().to(target_entity.device)

        d_entity = drug_entity[drug_ids]
        t_entity = target_entity[target_ids]
        d_compat = self.drug_compatibility_projection(d_entity)
        d_tokens = drug_tokens[drug_ids]
        t_tokens = target_tokens[target_ids]
        d_mask = drug_mask[drug_ids]
        t_mask = target_mask[target_ids]

        important_drug, important_mask, drug_substructure, atom_scores = self.drug_selector(d_tokens, d_mask)
        protein_binding, residue_weights = self.protein_pool(t_tokens, t_mask)
        d_ctx_tokens, interaction_matrix = self.drug_to_target(
            important_drug,
            t_tokens,
            t_tokens,
            key_padding_mask=~t_mask,
            need_weights=True,
            average_attn_weights=False,
        )
        p_ctx_token, reverse_attention = self.target_to_drug(
            protein_binding.unsqueeze(1),
            important_drug,
            important_drug,
            key_padding_mask=~important_mask,
            need_weights=True,
            average_attn_weights=False,
        )
        d_ctx = masked_mean(d_ctx_tokens, important_mask)
        t_ctx = p_ctx_token.squeeze(1)

        pair_input = torch.cat(
            (
                d_entity,
                t_entity,
                torch.abs(d_compat - t_entity),
                d_compat * t_entity,
                d_ctx,
                t_ctx,
                drug_substructure,
                protein_binding,
            ),
            dim=-1,
        )
        pair_repr = self.pair_proj(pair_input)
        affinity = self.reg_head(pair_repr)
        range_logits = self.range_head(pair_repr)
        interaction_aux = {
            "interaction_matrix": interaction_matrix,
            "reverse_attention": reverse_attention,
            "atom_importance": atom_scores,
            "residue_importance": residue_weights,
            "drug_substructure": drug_substructure,
            "protein_binding": protein_binding,
            "drug_compatibility_embedding": d_compat,
        }
        return affinity, range_logits, pair_repr, interaction_aux


class CPICDTAMultiscaleDrug(CPICDTA):
    """CPIC-DTA with optional graph/relation/Morgan drug entity fusion."""

    def __init__(
        self,
        tau,
        lam,
        ns_dims,
        drug_dims,
        target_dims,
        embedding_dim=128,
        edge_dropout_rate=0.2,
        max_drug_tokens=128,
        max_target_tokens=512,
        pair_heads=4,
        pair_dropout=0.1,
        drug_top_k=10,
        use_morgan_fp=True,
        morgan_fp_dim=2048,
        drug_view_dim=256,
    ):
        super().__init__(
            tau=tau,
            lam=lam,
            ns_dims=ns_dims,
            drug_dims=drug_dims,
            target_dims=target_dims,
            embedding_dim=embedding_dim,
            edge_dropout_rate=edge_dropout_rate,
            max_drug_tokens=max_drug_tokens,
            max_target_tokens=max_target_tokens,
            pair_heads=pair_heads,
            pair_dropout=pair_dropout,
            drug_top_k=drug_top_k,
        )
        self.use_morgan_fp = bool(use_morgan_fp)
        self.morgan_fp_dim = int(morgan_fp_dim)
        self.drug_view_dim = int(drug_view_dim)
        self.enhanced_drug_entity_dim = self.drug_view_dim * 3
        self.original_target_entity_dim = embedding_dim * 2
        self.register_buffer("morgan_fingerprints", torch.empty(0), persistent=False)

        # Optional modules must not perturb the RNG sequence of the original
        # path when --no_morgan_fp is used.
        cpu_rng_state = torch.get_rng_state()
        cuda_rng_state = torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None
        self.drug_graph_projection = DrugViewProjection(drug_dims[-1], self.drug_view_dim)
        self.drug_relation_projection = DrugViewProjection(ns_dims[-1], self.drug_view_dim)
        self.morgan_projection = MorganFingerprintProjection(
            self.morgan_fp_dim,
            self.drug_view_dim,
            dropout=pair_dropout,
        )
        self.multiscale_pair_head = MultiscaleDrugPairInteractionHead(
            drug_entity_dim=self.enhanced_drug_entity_dim,
            target_entity_dim=self.original_target_entity_dim,
            token_dim=drug_dims[-1],
            num_heads=pair_heads,
            dropout=pair_dropout,
            drug_top_k=drug_top_k,
        )
        torch.set_rng_state(cpu_rng_state)
        if cuda_rng_state is not None:
            torch.cuda.set_rng_state_all(cuda_rng_state)

    def load_morgan_fingerprints(self, fingerprints, device):
        fingerprints = torch.as_tensor(fingerprints, dtype=torch.float32)
        if fingerprints.dim() != 2 or fingerprints.size(1) != self.morgan_fp_dim:
            raise ValueError(
                f"Morgan fingerprint shape must be [num_drugs, {self.morgan_fp_dim}], "
                f"got {tuple(fingerprints.shape)}"
            )
        self.morgan_fingerprints = fingerprints.to(device)

    def encode_entities(self, affinity_graph, drug_graph_batch, target_graph_batch, drug_pos, target_pos):
        encoded = super().encode_entities(
            affinity_graph,
            drug_graph_batch,
            target_graph_batch,
            drug_pos,
            target_pos,
        )
        base_drug, target_entity, drug_tokens, drug_mask, target_tokens, target_mask, aux = encoded
        if not self.use_morgan_fp:
            return encoded
        if self.morgan_fingerprints.numel() == 0:
            raise RuntimeError(
                "Morgan fingerprints are enabled but not loaded; "
                "call load_morgan_fingerprints() before training"
            )
        if self.morgan_fingerprints.size(0) != aux["drug_graph_emb"].size(0):
            raise ValueError(
                f"Morgan drug count {self.morgan_fingerprints.size(0)} != "
                f"graph drug count {aux['drug_graph_emb'].size(0)}"
            )

        graph_view = self.drug_graph_projection(aux["drug_graph_emb"])
        relation_view = self.drug_relation_projection(aux["drug_relation_emb"])
        fingerprint_view = self.morgan_projection(self.morgan_fingerprints)
        enhanced_drug = torch.cat((graph_view, relation_view, fingerprint_view), dim=-1)
        aux.update(
            {
                "base_drug_entity": base_drug,
                "drug_graph_projection": graph_view,
                "drug_relation_projection": relation_view,
                "morgan_embedding": fingerprint_view,
                "enhanced_drug_entity": enhanced_drug,
            }
        )
        return enhanced_drug, target_entity, drug_tokens, drug_mask, target_tokens, target_mask, aux

    def forward(self, data, affinity_graph, drug_graph_batch, target_graph_batch, drug_pos, target_pos):
        encoded = self.encode_entities(
            affinity_graph,
            drug_graph_batch,
            target_graph_batch,
            drug_pos,
            target_pos,
        )
        drug_entity, target_entity, drug_tokens, drug_mask, target_tokens, target_mask, aux = encoded
        pair_head = self.multiscale_pair_head if self.use_morgan_fp else self.pair_head
        pred, range_logits, pair_repr, interaction_aux = pair_head(
            data,
            drug_entity,
            target_entity,
            drug_tokens,
            drug_mask,
            target_tokens,
            target_mask,
        )
        aux["pair_repr"] = pair_repr
        aux.update(interaction_aux)
        return pred, range_logits, aux


def censored_affinity_loss(pred, target, censored_value=5.0, margin=0.05, censored_weight=1.0):
    pred = pred.view(-1)
    target = target.view(-1)
    exact_mask = target > censored_value
    censored_mask = ~exact_mask

    losses = []
    if exact_mask.any():
        losses.append(F.mse_loss(pred[exact_mask], target[exact_mask]))
    if censored_mask.any():
        # affinity=5.0 is treated as a weak-binding lower-bound / censored label.
        censored_penalty = F.relu(pred[censored_mask] - (censored_value + margin)).pow(2).mean()
        losses.append(censored_weight * censored_penalty)
    if not losses:
        return F.mse_loss(pred, target)
    return sum(losses)


def binding_range_labels(y, dataset="davis", censored_value=5.0, low_cut=None, high_cut=None):
    y = y.view(-1)
    if low_cut is None:
        low_cut = censored_value if dataset.lower() == "davis" else 11.0
    if high_cut is None:
        high_cut = 7.0 if dataset.lower() == "davis" else 13.0
    labels = torch.zeros_like(y, dtype=torch.long)
    labels[y > low_cut] = 1
    labels[y >= high_cut] = 2
    return labels


def affinity_aware_supcon_loss(pair_repr, y, tau=0.2, sigma=1.0):
    if pair_repr.size(0) < 2:
        return pair_repr.new_tensor(0.0)
    z = F.normalize(pair_repr, dim=-1)
    sim = torch.matmul(z, z.t()) / tau
    logits_mask = ~torch.eye(z.size(0), dtype=torch.bool, device=z.device)
    sim = sim.masked_fill(~logits_mask, -1e9)

    y = y.view(-1, 1)
    weights = torch.exp(-torch.abs(y - y.t()) / sigma).detach()
    weights = weights * logits_mask.float()
    log_prob = sim - torch.logsumexp(sim, dim=1, keepdim=True)
    denom = weights.sum(dim=1).clamp_min(1e-8)
    loss = -(weights * log_prob).sum(dim=1) / denom
    return loss.mean()
