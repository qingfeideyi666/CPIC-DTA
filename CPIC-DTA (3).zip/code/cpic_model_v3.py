"""CPIC-DTA v3.

This module extends, rather than replaces, the v2 implementation in
``cpic_model.py``.  The affinity, drug, protein and contrastive encoders are
inherited unchanged.  Only the pair-specific interaction/prediction head is
replaced when ``--use_cross_attention`` is explicitly enabled.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from cpic_model import CPICDTA, masked_mean


class BidirectionalCrossAttention(nn.Module):
    """Explicit atom-to-residue and residue-to-atom attention."""

    def __init__(self, hidden_dim: int, num_heads: int, dropout: float):
        super().__init__()
        self.drug_to_protein = nn.MultiheadAttention(
            hidden_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.protein_to_drug = nn.MultiheadAttention(
            hidden_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.drug_norm = nn.LayerNorm(hidden_dim)
        self.protein_norm = nn.LayerNorm(hidden_dim)

    def forward(self, drug_tokens, protein_tokens, drug_mask, protein_mask):
        drug_context, _ = self.drug_to_protein(
            query=drug_tokens,
            key=protein_tokens,
            value=protein_tokens,
            key_padding_mask=~protein_mask,
            need_weights=False,
        )
        protein_context, _ = self.protein_to_drug(
            query=protein_tokens,
            key=drug_tokens,
            value=drug_tokens,
            key_padding_mask=~drug_mask,
            need_weights=False,
        )
        # Token-level residuals preserve the representations supplied by v2.
        drug_context = self.drug_norm(drug_tokens + drug_context)
        protein_context = self.protein_norm(protein_tokens + protein_context)
        return masked_mean(drug_context, drug_mask), masked_mean(protein_context, protein_mask)


class V3PairInteractionHead(nn.Module):
    """V2 predictor plus a prediction-independent cross-attention auxiliary branch."""

    def __init__(
        self,
        entity_dim: int = 256,
        token_dim: int = 256,
        num_heads: int = 4,
        dropout: float = 0.1,
        drug_top_k: int = 10,
        base_head: nn.Module | None = None,
    ):
        super().__init__()
        if base_head is None:
            raise ValueError("V3PairInteractionHead requires the preserved CPIC-DTA v2 pair head")
        self.base_head = base_head
        # No stochastic dropout in the auxiliary branch: this prevents it from
        # perturbing the RNG sequence used by the preserved v2 training path.
        self.cross_attention = BidirectionalCrossAttention(token_dim, num_heads, 0.0)
        self.interaction_projection = nn.Sequential(
            nn.Linear(token_dim * 2, 256),
            nn.LayerNorm(256),
            nn.GELU(),
        )

    def forward(self, data, drug_entity, target_entity, drug_tokens, drug_mask, target_tokens, target_mask):
        base_prediction, base_range, base_pair, base_aux = self.base_head(
            data,
            drug_entity,
            target_entity,
            drug_tokens,
            drug_mask,
            target_tokens,
            target_mask,
        )
        drug_ids = data.drug_id.view(-1).long().to(drug_entity.device)
        target_ids = data.target_id.view(-1).long().to(target_entity.device)
        atom_tokens, atom_mask = drug_tokens[drug_ids], drug_mask[drug_ids]
        residue_tokens, residue_mask = target_tokens[target_ids], target_mask[target_ids]

        # The consistency objective trains only the auxiliary branch.  V2
        # encoders and the base pair representation receive no gradients from it.
        drug_protein, protein_drug = self.cross_attention(
            atom_tokens.detach(), residue_tokens.detach(), atom_mask, residue_mask
        )
        interaction_feature = self.interaction_projection(
            torch.cat((drug_protein, protein_drug), dim=-1)
        )
        interaction_consistency_loss = F.mse_loss(interaction_feature, base_pair.detach())

        # CPIC-DTA v3.1 never feeds the auxiliary interaction feature into the
        # predictor.  Prediction and pair representation are exactly v2.
        prediction = base_prediction
        range_logits = base_range
        pair_repr = base_pair
        auxiliary = dict(base_aux)
        auxiliary.update({
            "v2_prediction": base_prediction,
            "v2_pair_repr": base_pair,
            "interaction_feature": interaction_feature,
            "interaction_fusion": torch.cat((base_pair.detach(), interaction_feature), dim=-1),
            "interaction_consistency_loss": interaction_consistency_loss,
        })
        return prediction, range_logits, pair_repr, auxiliary


class CPICDTAV3(CPICDTA):
    """CPIC-DTA v2 encoders with the optional v3 pair interaction head."""

    def __init__(
        self,
        tau,
        lam,
        ns_dims,
        drug_dims,
        target_dims,
        embedding_dim=128,
        edge_dropout_rate=0.2,
        max_drug_tokens=128,
        max_target_tokens=512,
        pair_heads=4,
        pair_dropout=0.1,
        drug_top_k=10,
    ):
        super().__init__(
            tau=tau,
            lam=lam,
            ns_dims=ns_dims,
            drug_dims=drug_dims,
            target_dims=target_dims,
            embedding_dim=embedding_dim,
            edge_dropout_rate=edge_dropout_rate,
            max_drug_tokens=max_drug_tokens,
            max_target_tokens=max_target_tokens,
            pair_heads=pair_heads,
            pair_dropout=pair_dropout,
            drug_top_k=drug_top_k,
        )
        preserved_v2_head = self.pair_head
        cpu_rng_state = torch.get_rng_state()
        cuda_rng_state = torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None
        self.pair_head = V3PairInteractionHead(
            entity_dim=embedding_dim * 2,
            token_dim=drug_dims[-1],
            num_heads=pair_heads,
            dropout=pair_dropout,
            drug_top_k=drug_top_k,
            base_head=preserved_v2_head,
        )
        # Extra-module initialization must not change v2 shuffling/dropout RNG.
        torch.set_rng_state(cpu_rng_state)
        if cuda_rng_state is not None:
            torch.cuda.set_rng_state_all(cuda_rng_state)
