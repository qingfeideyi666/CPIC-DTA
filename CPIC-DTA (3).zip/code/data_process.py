import json
import hashlib
import os
import os.path as osp
import pickle
from collections import OrderedDict
from pathlib import Path
from typing import Dict, Tuple

import networkx as nx
import numpy as np
import pandas as pd

# ORIGINAL MODULE MODIFIED: path-safe Davis/KIBA loading retained for EHAM-CSCoDTA.
import scipy.sparse as sp
import torch
from rdkit import Chem
from torch_geometric import data as DATA

from utils import DTADataset, dense_affinity_refine, min_max_normalize, sparse_mx_to_torch_sparse_tensor


PRO_RES_TABLE = [
    "A",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "K",
    "L",
    "M",
    "N",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "V",
    "W",
    "Y",
    "X",
]
PRO_RES_TO_INDEX = {residue: index for index, residue in enumerate(PRO_RES_TABLE)}

PRO_RES_ALIPHATIC_TABLE = ["A", "I", "L", "M", "V"]
PRO_RES_AROMATIC_TABLE = ["F", "W", "Y"]
PRO_RES_POLAR_NEUTRAL_TABLE = ["C", "N", "Q", "S", "T"]
PRO_RES_ACIDIC_CHARGED_TABLE = ["D", "E"]
PRO_RES_BASIC_CHARGED_TABLE = ["H", "K", "R"]


def _normalize_dict(dic):
    max_value = dic[max(dic, key=dic.get)]
    min_value = dic[min(dic, key=dic.get)]
    interval = float(max_value) - float(min_value)
    for key in dic.keys():
        dic[key] = (dic[key] - min_value) / interval
    dic["X"] = (max_value + min_value) / 2.0
    return dic


RES_WEIGHT_TABLE = _normalize_dict(
    {
        "A": 71.08,
        "C": 103.15,
        "D": 115.09,
        "E": 129.12,
        "F": 147.18,
        "G": 57.05,
        "H": 137.14,
        "I": 113.16,
        "K": 128.18,
        "L": 113.16,
        "M": 131.20,
        "N": 114.11,
        "P": 97.12,
        "Q": 128.13,
        "R": 156.19,
        "S": 87.08,
        "T": 101.11,
        "V": 99.13,
        "W": 186.22,
        "Y": 163.18,
    }
)
RES_PKA_TABLE = _normalize_dict(
    {
        "A": 2.34,
        "C": 1.96,
        "D": 1.88,
        "E": 2.19,
        "F": 1.83,
        "G": 2.34,
        "H": 1.82,
        "I": 2.36,
        "K": 2.18,
        "L": 2.36,
        "M": 2.28,
        "N": 2.02,
        "P": 1.99,
        "Q": 2.17,
        "R": 2.17,
        "S": 2.21,
        "T": 2.09,
        "V": 2.32,
        "W": 2.83,
        "Y": 2.32,
    }
)
RES_PKB_TABLE = _normalize_dict(
    {
        "A": 9.69,
        "C": 10.28,
        "D": 9.60,
        "E": 9.67,
        "F": 9.13,
        "G": 9.60,
        "H": 9.17,
        "I": 9.60,
        "K": 8.95,
        "L": 9.60,
        "M": 9.21,
        "N": 8.80,
        "P": 10.60,
        "Q": 9.13,
        "R": 9.04,
        "S": 9.15,
        "T": 9.10,
        "V": 9.62,
        "W": 9.39,
        "Y": 9.62,
    }
)
RES_PKX_TABLE = _normalize_dict(
    {
        "A": 0.00,
        "C": 8.18,
        "D": 3.65,
        "E": 4.25,
        "F": 0.00,
        "G": 0,
        "H": 6.00,
        "I": 0.00,
        "K": 10.53,
        "L": 0.00,
        "M": 0.00,
        "N": 0.00,
        "P": 0.00,
        "Q": 0.00,
        "R": 12.48,
        "S": 0.00,
        "T": 0.00,
        "V": 0.00,
        "W": 0.00,
        "Y": 0.00,
    }
)
RES_PL_TABLE = _normalize_dict(
    {
        "A": 6.00,
        "C": 5.07,
        "D": 2.77,
        "E": 3.22,
        "F": 5.48,
        "G": 5.97,
        "H": 7.59,
        "I": 6.02,
        "K": 9.74,
        "L": 5.98,
        "M": 5.74,
        "N": 5.41,
        "P": 6.30,
        "Q": 5.65,
        "R": 10.76,
        "S": 5.68,
        "T": 5.60,
        "V": 5.96,
        "W": 5.89,
        "Y": 5.96,
    }
)
RES_HYDROPHOBIC_PH2_TABLE = _normalize_dict(
    {
        "A": 47,
        "C": 52,
        "D": -18,
        "E": 8,
        "F": 92,
        "G": 0,
        "H": -42,
        "I": 100,
        "K": -37,
        "L": 100,
        "M": 74,
        "N": -41,
        "P": -46,
        "Q": -18,
        "R": -26,
        "S": -7,
        "T": 13,
        "V": 79,
        "W": 84,
        "Y": 49,
    }
)
RES_HYDROPHOBIC_PH7_TABLE = _normalize_dict(
    {
        "A": 41,
        "C": 49,
        "D": -55,
        "E": -31,
        "F": 100,
        "G": 0,
        "H": 8,
        "I": 99,
        "K": -23,
        "L": 97,
        "M": 74,
        "N": -28,
        "P": -46,
        "Q": -10,
        "R": -14,
        "S": -5,
        "T": 13,
        "V": 76,
        "W": 97,
        "Y": 63,
    }
)


def _project_root():
    return Path(__file__).resolve().parents[1]


def _candidate_data_roots(data_root):
    roots = []
    if data_root is not None:
        roots.append(Path(data_root))
    env_root = os.environ.get("CPIC_DTA_DATA_ROOT")
    if env_root:
        roots.append(Path(env_root))
    project_root = _project_root()
    roots.extend(
        [
            project_root / "data",
            Path("/data/coding/CPIC-DTA/data"),
            Path("/data/coding/dta/dta/data"),
        ]
    )
    seen = set()
    for root in roots:
        root = root.expanduser()
        key = str(root)
        if key not in seen:
            seen.add(key)
            yield root


def resolve_dataset_dir(data_root, dataset):
    candidates = []
    for root in _candidate_data_roots(data_root):
        candidates.extend([root / dataset, root / dataset / dataset, root])
    for candidate in candidates:
        if (candidate / "affinities").exists() and (candidate / "drugs.txt").exists():
            return candidate
    checked = "\n".join(f"  - {p}" for p in candidates)
    raise FileNotFoundError(
        f"Cannot locate dataset '{dataset}'. Expected affinities/drugs.txt under one of:\n{checked}\n"
        "On the server, run scripts/prepare_server_data.sh or pass --data_root explicitly."
    )


def load_data(dataset, data_root):
    dataset_dir = resolve_dataset_dir(data_root, dataset)
    with open(dataset_dir / "affinities", "rb") as f:
        affinity = pickle.load(f, encoding="latin1")
    affinity = np.asarray(affinity, dtype=np.float32)
    if dataset.lower() == "davis":
        affinity = -np.log10(affinity / 1e9)
    return affinity


def _load_json(path):
    with open(path, "r") as f:
        return json.load(f)


def _flatten_train_index(train_file):
    train_index = []
    for fold in train_file:
        train_index += fold
    return np.asarray(train_index, dtype=np.int64)


def _split_train_valid(indices, valid_ratio, seed):
    if valid_ratio <= 0:
        return indices, np.asarray([], dtype=np.int64)
    rng = np.random.default_rng(seed)
    shuffled = np.asarray(indices, dtype=np.int64).copy()
    rng.shuffle(shuffled)
    valid_size = max(1, int(round(len(shuffled) * valid_ratio)))
    return shuffled[valid_size:], shuffled[:valid_size]


def process_data(
    affinity_mat,
    dataset,
    data_root,
    feature_dir,
    num_pos,
    pos_threshold,
    valid_ratio=0.0,
    seed=2025,
    filter_censored=False,
    censored_value=5.0,
):
    dataset_dir = resolve_dataset_dir(data_root, dataset)
    train_index_all = _flatten_train_index(_load_json(dataset_dir / "S1_train_set.txt"))
    test_index = np.asarray(_load_json(dataset_dir / "S1_test_set.txt"), dtype=np.int64)
    overlap = np.intersect1d(train_index_all, test_index)
    if overlap.size:
        raise ValueError(f"Train/test index leakage detected: {overlap.size} overlapping interactions")
    if np.union1d(train_index_all, test_index).size != np.count_nonzero(~np.isnan(affinity_mat)):
        raise ValueError("S1 train/test indices do not cover the observed affinity interactions exactly")

    rows, cols = np.where(~np.isnan(affinity_mat))
    train_index, valid_index = _split_train_valid(train_index_all, valid_ratio, seed)

    def make_dataset(index):
        drug_ids, target_ids = rows[index], cols[index]
        labels = affinity_mat[drug_ids, target_ids]
        if filter_censored and dataset.lower() == "davis":
            keep = labels > censored_value
            drug_ids, target_ids, labels = drug_ids[keep], target_ids[keep], labels[keep]
        return DTADataset(drug_ids=drug_ids, target_ids=target_ids, y=labels), drug_ids, target_ids, labels

    train_dataset, train_rows, train_cols, train_y = make_dataset(train_index)
    valid_dataset, _, _, _ = make_dataset(valid_index)
    test_dataset, _, _, _ = make_dataset(test_index)

    train_affinity_mat = np.zeros_like(affinity_mat)
    train_affinity_mat[train_rows, train_cols] = train_y
    affinity_graph, drug_pos, target_pos = get_affinity_graph(
        dataset=dataset,
        adj=train_affinity_mat,
        data_root=data_root,
        feature_dir=feature_dir,
        num_pos=num_pos,
        pos_threshold=pos_threshold,
    )
    return train_dataset, valid_dataset, test_dataset, affinity_graph, drug_pos, target_pos


def _read_feature(path):
    return pd.read_csv(path, header=None).values.astype(np.float32)


def _candidate_feature_dirs(dataset_dir, feature_dir):
    dirs = [Path(dataset_dir)]
    if feature_dir is not None:
        dirs.append(Path(feature_dir))
    env_dir = os.environ.get("CPIC_DTA_FEATURE_DIR")
    if env_dir:
        dirs.append(Path(env_dir))
    project_root = _project_root()
    dirs.extend(
        [
            project_root / "features",
            Path("/data/coding/CPIC-DTA/features"),
            Path("/data/coding/dta/dta/code"),
        ]
    )
    seen = set()
    for directory in dirs:
        directory = directory.expanduser()
        key = str(directory)
        if key not in seen:
            seen.add(key)
            yield directory


def _feature_candidates(dataset_dir, feature_dir, names):
    for name in names:
        for base in _candidate_feature_dirs(dataset_dir, feature_dir):
            path = base / name
            if path.exists():
                yield path


def _load_feature_matrix(dataset_dir, feature_dir, names, expected_rows, fallback_dim):
    for path in _feature_candidates(dataset_dir, feature_dir, names):
        matrix = _read_feature(path)
        if matrix.shape[0] == expected_rows:
            return matrix
    return np.zeros((expected_rows, fallback_dim), dtype=np.float32)


def get_affinity_graph(dataset, adj, data_root, feature_dir, num_pos, pos_threshold):
    dataset_dir = resolve_dataset_dir(data_root, dataset)
    adj = np.asarray(adj, dtype=np.float32).copy()
    num_drug, num_target = adj.shape

    dt_ = np.where(adj >= pos_threshold, 1.0, 0.0)
    dtd = np.matmul(dt_, dt_.T)
    dtd = dtd / np.maximum(dtd.sum(axis=-1).reshape(-1, 1), 1e-8)
    dtd = np.nan_to_num(dtd).astype("float32") + np.eye(num_drug, dtype=np.float32)
    d_d = np.loadtxt(dataset_dir / "drug-drug-sim.txt", delimiter=",")
    d_all = dtd + d_d
    drug_pos = np.zeros((num_drug, num_drug), dtype=np.float32)
    for i in range(len(d_all)):
        nonzero = d_all[i].nonzero()[0]
        if len(nonzero) > num_pos:
            selected = nonzero[np.argsort(-d_all[i, nonzero])[:num_pos]]
            drug_pos[i, selected] = 1
        else:
            drug_pos[i, nonzero] = 1
    drug_pos = sparse_mx_to_torch_sparse_tensor(sp.coo_matrix(drug_pos))

    td_ = np.where(adj.T >= pos_threshold, 1.0, 0.0)
    tdt = np.matmul(td_, td_.T)
    tdt = tdt / np.maximum(tdt.sum(axis=-1).reshape(-1, 1), 1e-8)
    tdt = np.nan_to_num(tdt).astype("float32") + np.eye(num_target, dtype=np.float32)
    t_t = np.loadtxt(dataset_dir / "target-target-sim.txt", delimiter=",")
    t_all = tdt + t_t
    target_pos = np.zeros((num_target, num_target), dtype=np.float32)
    for i in range(len(t_all)):
        nonzero = t_all[i].nonzero()[0]
        if len(nonzero) > num_pos:
            selected = nonzero[np.argsort(-t_all[i, nonzero])[:num_pos]]
            target_pos[i, selected] = 1
        else:
            target_pos[i, nonzero] = 1
    target_pos = sparse_mx_to_torch_sparse_tensor(sp.coo_matrix(target_pos))

    if dataset.lower() == "davis":
        adj[adj == 5] = 0
        adj_norm = min_max_normalize(adj, 0)
    elif dataset.lower() == "kiba":
        adj_refine = dense_affinity_refine(adj.T, 150)
        adj_refine = dense_affinity_refine(adj_refine.T, 40)
        adj_norm = min_max_normalize(adj_refine, 0)
    else:
        adj_norm = min_max_normalize(adj, 0)

    bipartite_adj = np.concatenate(
        (
            np.concatenate((np.zeros([num_drug, num_drug]), adj_norm), axis=1),
            np.concatenate((adj_norm.T, np.zeros([num_target, num_target])), axis=1),
        ),
        axis=0,
    )
    row_ids, col_ids = np.where(bipartite_adj != 0)
    edge_index = np.vstack((row_ids, col_ids))
    edge_weight = bipartite_adj[row_ids, col_ids]

    node_type_features = np.concatenate(
        (
            np.tile(np.array([1, 0]), (num_drug, 1)),
            np.tile(np.array([0, 1]), (num_target, 1)),
        ),
        axis=0,
    )

    drug_1280 = _load_feature_matrix(dataset_dir, feature_dir, ["drugs_1280.csv", "drug_1280.csv"], num_drug, 1280)
    drug_128 = _load_feature_matrix(dataset_dir, feature_dir, ["drug_sq_128.csv"], num_drug, 128)
    protein_1280 = _load_feature_matrix(
        dataset_dir,
        feature_dir,
        ["protein_1280.csv", "proteins_1280.csv", "proteins_1280_kiba.csv"],
        num_target,
        1280,
    )
    protein_128 = _load_feature_matrix(dataset_dir, feature_dir, ["protein_sq_128.csv"], num_target, 128)
    drug_features = np.concatenate((drug_1280, drug_128), axis=1)
    protein_features = np.concatenate((protein_1280, protein_128), axis=1)
    seq_features = np.concatenate((drug_features, protein_features), axis=0)
    features = np.concatenate((node_type_features, seq_features), axis=1)

    graph = DATA.Data(
        x=torch.as_tensor(np.asarray(features, dtype=np.float32)),
        adj=torch.as_tensor(np.asarray(bipartite_adj, dtype=np.float32)),
        edge_index=torch.LongTensor(edge_index),
    )
    graph.__setitem__("edge_weight", torch.as_tensor(np.asarray(edge_weight, dtype=np.float32)))
    graph.__setitem__("num_drug", num_drug)
    graph.__setitem__("num_target", num_target)
    return graph, drug_pos, target_pos


def one_of_k_encoding(x, allowable_set):
    if x not in allowable_set:
        raise ValueError(f"input {x} not in allowable set {allowable_set}")
    return [x == s for s in allowable_set]


def one_of_k_encoding_unk(x, allowable_set):
    if x not in allowable_set:
        x = allowable_set[-1]
    return [x == s for s in allowable_set]


def atom_features(atom):
    return np.array(
        one_of_k_encoding_unk(
            atom.GetSymbol(),
            [
                "C",
                "N",
                "O",
                "S",
                "F",
                "Si",
                "P",
                "Cl",
                "Br",
                "Mg",
                "Na",
                "Ca",
                "Fe",
                "As",
                "Al",
                "I",
                "B",
                "V",
                "K",
                "Tl",
                "Yb",
                "Sb",
                "Sn",
                "Ag",
                "Pd",
                "Co",
                "Se",
                "Ti",
                "Zn",
                "H",
                "Li",
                "Ge",
                "Cu",
                "Au",
                "Ni",
                "Cd",
                "In",
                "Mn",
                "Zr",
                "Cr",
                "Pt",
                "Hg",
                "Pb",
                "X",
            ],
        )
        + one_of_k_encoding(atom.GetDegree(), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        + one_of_k_encoding_unk(atom.GetTotalNumHs(), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        + one_of_k_encoding_unk(atom.GetImplicitValence(), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        + [atom.GetIsAromatic()]
    )


def get_drug_molecule_graph(ligands):
    smile_graph = OrderedDict()
    for drug_key in ligands.keys():
        mol = Chem.MolFromSmiles(ligands[drug_key])
        if mol is None:
            continue
        canonical_smile = Chem.MolToSmiles(mol, isomericSmiles=True)
        smile_graph[drug_key] = smile_to_graph(canonical_smile)
    return smile_graph


def smile_to_graph(smile):
    mol = Chem.MolFromSmiles(smile)
    c_size = mol.GetNumAtoms()
    features = []
    for atom in mol.GetAtoms():
        feature = atom_features(atom)
        denom = max(float(np.sum(feature)), 1.0)
        features.append(feature / denom)

    edges = []
    for bond in mol.GetBonds():
        edges.append([bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()])
    graph = nx.Graph(edges).to_directed()
    mol_adj = np.zeros((c_size, c_size))
    for src, dst in graph.edges:
        mol_adj[src, dst] = 1
    mol_adj += np.eye(mol_adj.shape[0])
    edge_index = [[i, j] for i, j in zip(*np.where(mol_adj >= 0.5))]
    return c_size, features, edge_index


def get_target_molecule_graph(proteins, dataset, data_root):
    dataset_dir = resolve_dataset_dir(data_root, dataset)
    aln_dir = dataset_dir / "aln"
    contact_dir = dataset_dir / "pconsc4"
    pssm_cache_dir = _pssm_cache_dir(dataset)
    pssm_cache_dir.mkdir(parents=True, exist_ok=True)
    target_graph = OrderedDict()
    total = len(proteins)
    print(f"Building target graphs: {total} targets", flush=True)
    for index, (target_key, target_sequence) in enumerate(proteins.items(), start=1):
        progress_label = f"[target {index}/{total}] {target_key}"
        print(f"{progress_label}: length={len(target_sequence)}", flush=True)
        target_graph[target_key] = target_to_graph(
            target_key,
            target_sequence,
            contact_dir,
            aln_dir,
            pssm_cache_dir=pssm_cache_dir,
            progress_label=progress_label,
        )
    return target_graph


def target_to_graph(target_key, target_sequence, contact_dir, aln_dir, pssm_cache_dir=None, progress_label=None):
    target_size = len(target_sequence)
    contact_file = osp.join(contact_dir, target_key + ".npy")
    target_feature_mat = target_to_feature(
        target_key,
        target_sequence,
        aln_dir,
        pssm_cache_dir=pssm_cache_dir,
        progress_label=progress_label,
    )
    contact_map = np.load(contact_file)
    contact_map += np.eye(target_size)
    target_edge_index = np.array([[i, j] for i, j in zip(*np.where(contact_map >= 0.5))])
    return target_size, target_feature_mat, target_edge_index


def target_to_feature(target_key, target_sequence, aln_dir, pssm_cache_dir=None, progress_label=None):
    aln_file = osp.join(aln_dir, target_key + ".aln")
    pssm = load_or_build_pssm(target_key, target_sequence, aln_file, pssm_cache_dir, progress_label)
    other_feature = seq_feature(target_sequence)
    return np.concatenate((pssm.T, other_feature), axis=1)


def _pssm_cache_dir(dataset):
    env_dir = os.environ.get("CPIC_DTA_PSSM_CACHE_DIR")
    if env_dir:
        return Path(env_dir).expanduser() / dataset
    return _project_root() / "results" / "pssm_cache" / dataset


def _safe_cache_name(name):
    text = str(name)
    return "".join(char if char.isalnum() or char in "._-" else "_" for char in text)


def _pssm_cache_path(cache_dir, target_key, protein_sequence, aln_file):
    aln_path = Path(aln_file)
    stat = aln_path.stat()
    fingerprint = f"{target_key}|{len(protein_sequence)}|{stat.st_size}|{int(stat.st_mtime)}"
    digest = hashlib.md5(fingerprint.encode("utf-8")).hexdigest()[:12]
    return Path(cache_dir) / f"{_safe_cache_name(target_key)}_{len(protein_sequence)}_{digest}.npy"


def load_or_build_pssm(target_key, protein_sequence, aln_file, cache_dir=None, progress_label=None):
    label = progress_label or str(target_key)
    if cache_dir is None:
        return pssm_calculation(aln_file, protein_sequence)

    cache_path = _pssm_cache_path(cache_dir, target_key, protein_sequence, aln_file)
    if cache_path.exists():
        try:
            pssm = np.load(cache_path, allow_pickle=False)
            expected_shape = (len(PRO_RES_TABLE), len(protein_sequence))
            if pssm.shape == expected_shape:
                print(f"{label}: PSSM cache hit", flush=True)
                return pssm
            print(
                f"{label}: ignored stale PSSM cache with shape {pssm.shape}, expected {expected_shape}",
                flush=True,
            )
        except Exception as exc:
            print(f"{label}: ignored unreadable PSSM cache ({exc})", flush=True)

    print(f"{label}: PSSM cache miss, calculating from {Path(aln_file).name}", flush=True)
    pssm = pssm_calculation(aln_file, protein_sequence)
    tmp_path = cache_path.with_suffix(cache_path.suffix + ".tmp")
    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        with open(tmp_path, "wb") as f:
            np.save(f, pssm)
        os.replace(tmp_path, cache_path)
        print(f"{label}: saved PSSM cache -> {cache_path}", flush=True)
    finally:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass
    return pssm


def pssm_calculation(aln_file, protein_sequence):
    pfm_mat = np.zeros((len(PRO_RES_TABLE), len(protein_sequence)))
    with open(aln_file, "r") as f:
        lines = [line.strip() for line in f.readlines() if line.strip()]
    line_count = max(len(lines), 1)
    for line in lines:
        if len(line) != len(protein_sequence):
            continue
        for count, residue in enumerate(line):
            residue_index = PRO_RES_TO_INDEX.get(residue)
            if residue_index is not None:
                pfm_mat[residue_index, count] += 1
    pseudocount = 0.8
    return (pfm_mat + pseudocount / 4) / (float(line_count) + pseudocount)


def residue_features(residue):
    residue = residue if residue in PRO_RES_TABLE else "X"
    property1 = [
        1 if residue in PRO_RES_ALIPHATIC_TABLE else 0,
        1 if residue in PRO_RES_AROMATIC_TABLE else 0,
        1 if residue in PRO_RES_POLAR_NEUTRAL_TABLE else 0,
        1 if residue in PRO_RES_ACIDIC_CHARGED_TABLE else 0,
        1 if residue in PRO_RES_BASIC_CHARGED_TABLE else 0,
    ]
    property2 = [
        RES_WEIGHT_TABLE[residue],
        RES_PKA_TABLE[residue],
        RES_PKB_TABLE[residue],
        RES_PKX_TABLE[residue],
        RES_PL_TABLE[residue],
        RES_HYDROPHOBIC_PH2_TABLE[residue],
        RES_HYDROPHOBIC_PH7_TABLE[residue],
    ]
    return np.array(property1 + property2)


def seq_feature(protein_sequence):
    protein_hot = np.zeros((len(protein_sequence), len(PRO_RES_TABLE)))
    protein_property = np.zeros((len(protein_sequence), 12))
    for i, residue in enumerate(protein_sequence):
        residue = residue if residue in PRO_RES_TABLE else "X"
        protein_hot[i] = one_of_k_encoding(residue, PRO_RES_TABLE)
        protein_property[i] = residue_features(residue)
    return np.concatenate((protein_hot, protein_property), axis=1)
