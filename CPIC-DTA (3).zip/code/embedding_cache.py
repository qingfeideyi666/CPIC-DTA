"""Per-epoch differentiable entity caches and optional frozen ESM disk cache."""

# NEW MODULE - computational scheduling only; no model layers are added.

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import torch


@dataclass
class EpochEmbeddingCache:
    drug_embedding: torch.Tensor
    target_embedding: torch.Tensor
    drug_tokens: torch.Tensor
    drug_mask: torch.Tensor
    target_tokens: torch.Tensor
    target_mask: torch.Tensor
    auxiliary: Dict[str, torch.Tensor]

    @classmethod
    def build(cls, model, affinity_graph, drug_graph_batch, target_graph_batch, drug_pos, target_pos):
        """Build once per epoch while preserving autograd for trainable GNN encoders."""
        encoded = model.encode_entities(
            affinity_graph, drug_graph_batch, target_graph_batch, drug_pos, target_pos
        )
        return cls(*encoded)

    def detached(self) -> "EpochEmbeddingCache":
        """Detach the cache for validation/test, where encoder gradients are unnecessary."""
        return EpochEmbeddingCache(
            self.drug_embedding.detach(), self.target_embedding.detach(),
            self.drug_tokens.detach(), self.drug_mask,
            self.target_tokens.detach(), self.target_mask,
            {key: value.detach() if torch.is_tensor(value) else value for key, value in self.auxiliary.items()},
        )


def save_frozen_esm_embeddings(embeddings: torch.Tensor, output_dir, metadata: Optional[Dict[str, Any]] = None):
    """Persist precomputed frozen ESM features; unused by the CPIC baseline."""
    path = Path(output_dir) / "target_esm_embedding.pt"
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"embeddings": embeddings.detach().cpu(), "metadata": metadata or {}}, path)
    return path


def load_frozen_esm_embeddings(output_dir, device="cpu"):
    """Load `target_esm_embedding.pt` without invoking ESM inside model.forward."""
    path = Path(output_dir) / "target_esm_embedding.pt"
    if not path.exists():
        raise FileNotFoundError(f"Frozen ESM cache not found: {path}")
    try:
        payload = torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        payload = torch.load(path, map_location=device)
    return payload["embeddings"], payload.get("metadata", {})
