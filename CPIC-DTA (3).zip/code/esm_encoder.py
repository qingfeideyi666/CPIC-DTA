"""ESM-2 protein encoder with frozen and fine-tuning modes."""

# NEW MODULE

from __future__ import annotations

from pathlib import Path
from typing import Sequence

import torch
import torch.nn as nn


ESM2_SMALL = "facebook/esm2_t6_8M_UR50D"
ESM2_BASE = "facebook/esm2_t33_650M_UR50D"


class ESMEncoder(nn.Module):
    """Lazy HuggingFace ESM-2 wrapper; no model download occurs during import."""

    def __init__(self, output_dim=256, model_name=ESM2_SMALL, freeze=True, max_length=1024,
                 local_files_only=False, fallback_vocab_size=32):
        super().__init__()
        self.model_name = model_name
        self.freeze = freeze
        self.max_length = max_length
        self.local_files_only = local_files_only
        self.tokenizer = None
        self.esm = None
        self.projection = nn.LazyLinear(output_dim)
        # An explicit offline fallback keeps tests and ablations runnable without silently pretending it is ESM-2.
        self.fallback_embedding = nn.Embedding(fallback_vocab_size, output_dim, padding_idx=0)
        if output_dim % 4 != 0:
            raise ValueError("output_dim must be divisible by 4")
        layer = nn.TransformerEncoderLayer(output_dim, 4, output_dim * 2, batch_first=True)
        self.fallback_encoder = nn.TransformerEncoder(layer, 2)
        alphabet = "ACDEFGHIKLMNPQRSTVWYBXZJUO"
        self._aa_to_id = {aa: i + 1 for i, aa in enumerate(alphabet)}

    def _load_esm(self, device):
        if self.esm is not None:
            return
        try:
            from transformers import AutoModel, AutoTokenizer
        except ImportError as exc:
            raise ImportError("ESM-2 requires `pip install transformers sentencepiece` or use backend='fallback'.") from exc
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name, local_files_only=self.local_files_only)
        self.esm = AutoModel.from_pretrained(self.model_name, local_files_only=self.local_files_only).to(device)
        self.esm.requires_grad_(not self.freeze)
        if self.freeze:
            self.esm.eval()

    def _fallback(self, sequences: Sequence[str], device):
        length = min(max(map(len, sequences)), self.max_length)
        ids = torch.zeros((len(sequences), length), dtype=torch.long, device=device)
        mask = torch.zeros_like(ids, dtype=torch.bool)
        for row, seq in enumerate(sequences):
            encoded = [self._aa_to_id.get(aa.upper(), self._aa_to_id["X"]) for aa in seq[:length]]
            if encoded:
                ids[row, :len(encoded)] = torch.tensor(encoded, device=device)
                mask[row, :len(encoded)] = True
        tokens = self.fallback_encoder(self.fallback_embedding(ids), src_key_padding_mask=~mask)
        return tokens, mask

    def forward(self, sequences: Sequence[str], device=None, backend="esm2"):
        if not sequences:
            raise ValueError("sequences cannot be empty")
        device = device or next(self.parameters()).device
        if backend == "fallback":
            hidden, mask = self._fallback(sequences, device)
            return self.projection(hidden), mask
        self._load_esm(device)
        encoded = self.tokenizer(list(sequences), return_tensors="pt", padding=True, truncation=True,
                                 max_length=self.max_length, add_special_tokens=True)
        encoded = {k: v.to(device) for k, v in encoded.items()}
        context = torch.no_grad() if self.freeze else torch.enable_grad()
        with context:
            hidden = self.esm(**encoded).last_hidden_state
        # Strip BOS/EOS by using the attention mask and explicitly masking boundary tokens.
        mask = encoded["attention_mask"].bool()
        mask[:, 0] = False
        last = mask.sum(1).clamp_min(1)
        mask[torch.arange(mask.size(0), device=device), last] = False
        hidden = self.projection(hidden)
        return hidden, mask

    @torch.no_grad()
    def precompute(self, sequences: Sequence[str], output_path, device=None, backend="esm2", batch_size=4):
        """Encode once and persist projected residue tokens for training-time indexing."""
        if not self.freeze:
            raise ValueError("ESM precompute requires frozen parameters")
        device = device or next(self.parameters()).device
        chunks, masks = [], []
        for start in range(0, len(sequences), batch_size):
            tokens, mask = self.forward(sequences[start:start + batch_size], device, backend)
            # Keep residue positions only; padding is normalized globally below.
            chunks.extend([tokens[i, mask[i]].cpu() for i in range(tokens.size(0))])
        max_len = min(max(t.size(0) for t in chunks), self.max_length)
        hidden_dim = chunks[0].size(-1)
        all_tokens = torch.zeros((len(chunks), max_len, hidden_dim), dtype=chunks[0].dtype)
        all_mask = torch.zeros((len(chunks), max_len), dtype=torch.bool)
        for row, tokens in enumerate(chunks):
            length = min(tokens.size(0), max_len)
            all_tokens[row, :length] = tokens[:length]
            all_mask[row, :length] = True
        pooled = (all_tokens * all_mask.unsqueeze(-1)).sum(1) / all_mask.sum(1, keepdim=True).clamp_min(1)
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            "tokens": all_tokens,
            "mask": all_mask,
            "pooled": pooled,
            "model_name": self.model_name,
            "backend": backend,
            "sequence_count": len(sequences),
            "max_length": self.max_length,
            "projection_in_features": self.projection.in_features,
        }, path)
        return path
