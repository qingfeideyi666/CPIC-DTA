"""Losses for EHAM-CSCoDTA."""

# NEW MODULE

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class InfoNCELoss(nn.Module):
    """Symmetric in-batch InfoNCE with matching rows as positive pairs."""

    def __init__(self, temperature: float = 0.2):
        super().__init__()
        if temperature <= 0:
            raise ValueError("temperature must be positive")
        self.temperature = temperature

    def forward(self, view_a: torch.Tensor, view_b: torch.Tensor) -> torch.Tensor:
        if view_a.shape != view_b.shape or view_a.dim() != 2:
            raise ValueError(f"InfoNCE expects equal [N,D] tensors, got {view_a.shape} and {view_b.shape}")
        if view_a.size(0) < 2:
            return view_a.sum() * 0.0
        a = F.normalize(view_a, dim=-1)
        b = F.normalize(view_b, dim=-1)
        logits = a @ b.t() / self.temperature
        labels = torch.arange(a.size(0), device=a.device)
        return 0.5 * (F.cross_entropy(logits, labels) + F.cross_entropy(logits.t(), labels))


def cosine_alignment_loss(view_a: torch.Tensor, view_b: torch.Tensor) -> torch.Tensor:
    """Stable row-wise semantic alignment loss."""
    if view_a.shape != view_b.shape:
        raise ValueError(f"alignment expects equal shapes, got {view_a.shape} and {view_b.shape}")
    return 1.0 - F.cosine_similarity(view_a, view_b, dim=-1).mean()
