"""Fast-scheduled CPIC-DTA with an unchanged model architecture."""

# ORIGINAL MODULE MODIFIED: only forward scheduling is split into encode/predict stages.

from __future__ import annotations

from cpic_model import (
    CPICDTA,
    affinity_aware_supcon_loss,
    binding_range_labels,
    censored_affinity_loss,
)


class FastCPICDTA(CPICDTA):
    """The exact CPICDTA layers with a cache-aware predictor method."""

    def predict_from_cache(self, data, cache):
        pred, range_logits, pair_repr = self.pair_head(
            data,
            cache.drug_embedding,
            cache.target_embedding,
            cache.drug_tokens,
            cache.drug_mask,
            cache.target_tokens,
            cache.target_mask,
        )
        return pred, range_logits, pair_repr


__all__ = [
    "FastCPICDTA",
    "affinity_aware_supcon_loss",
    "binding_range_labels",
    "censored_affinity_loss",
]
