"""EHAM-CSCoDTA: an ESM2-enhanced extension of CSCo-DTA."""

# NEW MODULE

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import DenseGCNConv, GCNConv, global_mean_pool
from torch_geometric.utils import dropout_edge

from attention_module import MutualAttention
from esm_encoder import ESM2_SMALL, ESMEncoder
from loss import InfoNCELoss, cosine_alignment_loss


def to_dense_tokens(node_x, batch, max_tokens):
    batch_size = int(batch.max().item()) + 1 if batch.numel() else 0
    tokens = node_x.new_zeros((batch_size, max_tokens, node_x.size(-1)))
    mask = torch.zeros((batch_size, max_tokens), dtype=torch.bool, device=node_x.device)
    for graph_id in range(batch_size):
        ids = torch.where(batch == graph_id)[0][:max_tokens]
        tokens[graph_id, :ids.numel()] = node_x[ids]
        mask[graph_id, :ids.numel()] = True
    return tokens, mask


class _GraphEncoder(nn.Module):
    def __init__(self, input_dim, hidden_dim=256, num_layers=3, dropout=0.1, max_tokens=512):
        super().__init__()
        dims = [input_dim] + [hidden_dim] * num_layers
        self.convs = nn.ModuleList(GCNConv(dims[i], dims[i + 1]) for i in range(num_layers))
        self.norms = nn.ModuleList(nn.LayerNorm(hidden_dim) for _ in range(num_layers))
        self.dropout, self.max_tokens = nn.Dropout(dropout), max_tokens

    def forward(self, graph):
        x = graph.x
        for conv, norm in zip(self.convs, self.norms):
            x = self.dropout(F.gelu(norm(conv(x, graph.edge_index))))
        pooled = global_mean_pool(x, graph.batch)
        tokens, mask = to_dense_tokens(x, graph.batch, self.max_tokens)
        return pooled, tokens, mask


class DrugGraphEncoder(_GraphEncoder):
    """Original CSCo-DTA atom-graph view, retaining atom-level tokens."""


class ProteinGraphEncoder(_GraphEncoder):
    """Original CSCo-DTA residue/contact-graph view."""


class LineGraphEncoder(nn.Module):
    """Bond-centric line-graph view constructed directly from the unchanged atom graph."""

    def __init__(self, atom_dim=78, hidden_dim=256, num_layers=2, dropout=0.1):
        super().__init__()
        self.input_proj = nn.Linear(atom_dim * 2, hidden_dim)
        self.convs = nn.ModuleList(GCNConv(hidden_dim, hidden_dim) for _ in range(num_layers))
        self.norms = nn.ModuleList(nn.LayerNorm(hidden_dim) for _ in range(num_layers))
        self.dropout = nn.Dropout(dropout)

    @staticmethod
    def _build(atom_x, edge_index, atom_batch):
        src, dst = edge_index
        keep = src < dst  # removes self-loops and collapses the two directed copies of each bond
        src, dst = src[keep], dst[keep]
        graph_ids = torch.arange(int(atom_batch.max()) + 1, device=atom_x.device)
        present = torch.zeros(graph_ids.numel(), dtype=torch.bool, device=atom_x.device)
        if src.numel():
            present[atom_batch[src].unique()] = True
        missing = graph_ids[~present]
        if missing.numel():
            # One-atom/ion molecules receive an isolated pseudo-bond so pooling preserves every graph row.
            first = torch.stack([torch.where(atom_batch == g)[0][0] for g in missing])
            src = torch.cat((src, first)); dst = torch.cat((dst, first))
        features = torch.cat((atom_x[src], atom_x[dst]), -1)
        bond_batch = atom_batch[src]
        incident = (src[:, None] == src[None, :]) | (src[:, None] == dst[None, :]) | \
                   (dst[:, None] == src[None, :]) | (dst[:, None] == dst[None, :])
        incident.fill_diagonal_(False)
        line_edges = incident.nonzero(as_tuple=False).t().contiguous()
        return features, line_edges, bond_batch

    def forward(self, drug_graph):
        x, edge_index, batch = self._build(drug_graph.x, drug_graph.edge_index, drug_graph.batch)
        x = self.input_proj(x)
        for conv, norm in zip(self.convs, self.norms):
            x = self.dropout(F.gelu(norm(conv(x, edge_index))))
        return global_mean_pool(x, batch)


class ESMEncoder(ESMEncoder):
    """Public model-file alias required by the EHAM-CSCoDTA module API."""


class HierarchicalAffinityEncoder(nn.Module):
    """Fuses local one-hop and global dense/coarse affinity-graph representations."""

    def __init__(self, input_dim=1410, hidden_dim=256, dropout=0.1, edge_dropout=0.2):
        super().__init__()
        self.local1, self.local2 = GCNConv(input_dim, hidden_dim), GCNConv(hidden_dim, hidden_dim)
        self.global1, self.global2 = DenseGCNConv(input_dim, hidden_dim), DenseGCNConv(hidden_dim, hidden_dim)
        self.gate = nn.Sequential(nn.Linear(hidden_dim * 2, hidden_dim), nn.Sigmoid())
        self.norm, self.dropout, self.edge_dropout = nn.LayerNorm(hidden_dim), nn.Dropout(dropout), edge_dropout

    def forward(self, graph):
        edge_index, _ = dropout_edge(graph.edge_index, p=self.edge_dropout, training=self.training)
        local = F.gelu(self.local1(graph.x, edge_index))
        local = self.local2(local, edge_index)
        # A^2 adds meta-path/co-neighbour information while preserving the original affinity graph.
        adj = graph.adj
        coarse = torch.clamp(adj + adj @ adj, min=0.0)
        scale = coarse.abs().sum(-1, keepdim=True).clamp_min(1.0)
        coarse = coarse / scale
        global_x = F.gelu(self.global1(graph.x, coarse, add_loop=False)).squeeze(0)
        global_x = self.global2(global_x, coarse, add_loop=False).squeeze(0)
        gate = self.gate(torch.cat((local, global_x), -1))
        fused = self.norm(gate * local + (1.0 - gate) * global_x)
        return self.dropout(fused), local, global_x


class ContrastiveLearningModule(nn.Module):
    """Cross-scale supervised-positive contrast plus new multi-view InfoNCE losses."""

    def __init__(self, hidden_dim=256, projection_dim=128, temperature=0.2):
        super().__init__()
        self.project = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.ELU(), nn.Linear(hidden_dim, projection_dim))
        self.info_nce = InfoNCELoss(temperature)

    def pair(self, a, b):
        return self.info_nce(self.project(a), self.project(b))

    def positive_graph_loss(self, relation, molecular, positive_mask):
        a = F.normalize(self.project(relation), dim=-1)
        b = F.normalize(self.project(molecular), dim=-1)
        logits = a @ b.t() / self.info_nce.temperature
        mask = positive_mask.to_dense().to(logits.device).bool()
        log_prob = logits - torch.logsumexp(logits, 1, keepdim=True)
        row_loss = -(log_prob.masked_fill(~mask, 0.0).sum(1) / mask.sum(1).clamp_min(1))
        return row_loss.mean()


class _GatedFusion(nn.Module):
    def __init__(self, hidden_dim=256):
        super().__init__()
        self.gate = nn.Sequential(nn.Linear(hidden_dim * 2, hidden_dim), nn.Sigmoid())
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, a, b):
        g = self.gate(torch.cat((a, b), -1))
        return self.norm(g * a + (1 - g) * b)


class EHAM_CSCoDTA(nn.Module):
    """ESM2 Hierarchical Attention Multi-view Contrastive DTA predictor."""

    def __init__(self, affinity_input_dim=1410, hidden_dim=256, atom_dim=78, protein_dim=54,
                 max_drug_tokens=128, max_target_tokens=1024, attention_heads=4,
                 esm_model=ESM2_SMALL, freeze_esm=True, esm_backend="esm2", dropout=0.1,
                 edge_dropout=0.2, contrast_temperature=0.2):
        super().__init__()
        self.esm_backend = esm_backend
        self.drug_graph_encoder = DrugGraphEncoder(atom_dim, hidden_dim, 3, dropout, max_drug_tokens)
        self.line_graph_encoder = LineGraphEncoder(atom_dim, hidden_dim, 2, dropout)
        self.protein_graph_encoder = ProteinGraphEncoder(protein_dim, hidden_dim, 3, dropout, max_target_tokens)
        self.esm_encoder = ESMEncoder(hidden_dim, esm_model, freeze_esm, max_target_tokens)
        self.affinity_encoder = HierarchicalAffinityEncoder(affinity_input_dim, hidden_dim, dropout, edge_dropout)
        self.drug_fusion, self.protein_fusion = _GatedFusion(hidden_dim), _GatedFusion(hidden_dim)
        self.drug_relation_fusion, self.target_relation_fusion = _GatedFusion(hidden_dim), _GatedFusion(hidden_dim)
        self.mutual_attention = MutualAttention(hidden_dim, attention_heads, dropout)
        self.contrastive = ContrastiveLearningModule(hidden_dim, hidden_dim // 2, contrast_temperature)
        self.predictor = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim * 2), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, 1),
        )
        self._esm_cache = None

    def load_precomputed_esm(self, cache_path, device):
        """Load frozen ESM tokens once; training forward never invokes the ESM model."""
        try:
            payload = torch.load(cache_path, map_location="cpu", weights_only=False)
        except TypeError:
            payload = torch.load(cache_path, map_location="cpu")
        self._esm_cache = {
            "tokens": payload["tokens"].to(device),
            "mask": payload["mask"].to(device),
            "pooled": payload["pooled"].to(device),
        }
        in_features = payload.get("projection_in_features")
        if in_features and hasattr(self.esm_encoder.projection, "has_uninitialized_params") and \
                self.esm_encoder.projection.has_uninitialized_params():
            self.esm_encoder.projection.initialize_parameters(torch.zeros(1, in_features, device=device))
        self.esm_encoder.requires_grad_(False)
        # Release the large language model after preprocessing.
        self.esm_encoder.esm = None
        self.esm_encoder.tokenizer = None
        return payload

    def encode_entities(self, affinity_graph, drug_graph, protein_graph, drug_pos, target_pos):
        """Build all trainable entity embeddings exactly once per epoch."""
        if self._esm_cache is None:
            raise RuntimeError("Call load_precomputed_esm() before training")
        d_graph, d_tokens, d_mask = self.drug_graph_encoder(drug_graph)
        d_line = self.line_graph_encoder(drug_graph)
        p_graph, p_tokens, p_mask = self.protein_graph_encoder(protein_graph)
        p_esm_tokens = self._esm_cache["tokens"]
        p_esm_mask = self._esm_cache["mask"]
        p_esm = self._esm_cache["pooled"]
        if p_esm.size(0) != p_graph.size(0):
            raise ValueError(f"ESM targets={p_esm.size(0)} but protein graphs={p_graph.size(0)}")
        d_multi, p_multi = self.drug_fusion(d_graph, d_line), self.protein_fusion(p_graph, p_esm)

        affinity, affinity_local, affinity_global = self.affinity_encoder(affinity_graph)
        nd = int(affinity_graph.num_drug)
        d_entity = self.drug_relation_fusion(d_multi, affinity[:nd])
        p_entity = self.target_relation_fusion(p_multi, affinity[nd:])

        contrastive_loss = self.contrastive.positive_graph_loss(affinity[:nd], d_graph, drug_pos) + \
                           self.contrastive.positive_graph_loss(affinity[nd:], p_graph, target_pos) + \
                           self.contrastive.pair(d_graph, d_line) + self.contrastive.pair(p_graph, p_esm)
        view_consistency_loss = F.mse_loss(d_graph, d_line) + F.mse_loss(p_graph, p_esm)
        alignment_loss = cosine_alignment_loss(affinity[:nd], d_multi) + \
                         cosine_alignment_loss(affinity[nd:], p_multi) + \
                         F.mse_loss(affinity_local, affinity_global)
        aux = dict(contrastive_loss=contrastive_loss, view_consistency_loss=view_consistency_loss,
                   alignment_loss=alignment_loss,
                   drug_graph_embedding=d_graph, drug_line_embedding=d_line,
                   protein_graph_embedding=p_graph, esm_embedding=p_esm,
                   local_affinity_embedding=affinity_local, global_affinity_embedding=affinity_global)
        return d_entity, p_entity, d_tokens, d_mask, p_esm_tokens, p_esm_mask, aux

    def predict_from_cache(self, pairs, cache):
        """Index cached entities and run only pair-specific interaction/prediction."""
        did = pairs.drug_id.view(-1).long().to(cache.drug_embedding.device)
        tid = pairs.target_id.view(-1).long().to(cache.target_embedding.device)
        interaction, attention = self.mutual_attention(
            cache.drug_tokens[did], cache.target_tokens[tid],
            cache.drug_mask[did], cache.target_mask[tid],
        )
        pair_features = torch.cat((cache.drug_embedding[did], cache.target_embedding[tid], interaction), -1)
        prediction = self.predictor(pair_features)
        return prediction, {"attention": attention, "interaction_embedding": interaction}

    def forward(self, pairs, affinity_graph, drug_graph, protein_graph, drug_pos, target_pos):
        """Compatibility path using the precomputed ESM cache; never calls ESM."""
        from embedding_cache import EpochEmbeddingCache
        cache = EpochEmbeddingCache.build(self, affinity_graph, drug_graph, protein_graph, drug_pos, target_pos)
        prediction, pair_aux = self.predict_from_cache(pairs, cache)
        aux = dict(cache.auxiliary)
        aux.update(pair_aux)
        return prediction, aux
