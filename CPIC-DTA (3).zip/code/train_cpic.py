import argparse
import json
import math
import os
import random
import time
from collections import OrderedDict
from datetime import datetime
from itertools import chain
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from cpic_model import CPICDTA, affinity_aware_supcon_loss, binding_range_labels, censored_affinity_loss
from cpic_model_v3 import CPICDTAV3
from data_process import (
    get_drug_molecule_graph,
    get_target_molecule_graph,
    load_data,
    process_data,
    resolve_dataset_dir,
)
from utils import GraphDataset, collate, evaluate_regression, format_metrics, metric_is_better


def safe_torch_load(path, map_location="cpu"):
    try:
        return torch.load(path, map_location=map_location, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=map_location)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def build_arg_parser():
    project_root = Path(__file__).resolve().parents[1]
    default_data_root = os.environ.get("CPIC_DTA_DATA_ROOT", str(project_root / "data"))
    default_feature_dir = os.environ.get("CPIC_DTA_FEATURE_DIR", str(project_root / "features"))
    default_result_dir = os.environ.get("CPIC_DTA_RESULT_DIR", str(project_root / "results"))
    parser = argparse.ArgumentParser(description="Train CPIC-DTA.")
    parser.add_argument("--dataset", type=str, default="davis", choices=["davis", "kiba"])
    parser.add_argument("--data_root", type=str, default=default_data_root)
    parser.add_argument("--feature_dir", type=str, default=default_feature_dir)
    parser.add_argument("--result_dir", type=str, default=default_result_dir)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5])
    parser.add_argument("--epochs", type=int, default=500)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=5e-4)
    parser.add_argument(
        "--use_cosine_lr",
        action="store_true",
        help="Decay the learning rate from --lr to --min_lr before SWA or the final epoch.",
    )
    parser.add_argument("--min_lr", type=float, default=1e-6)
    parser.add_argument(
        "--regression_finetune_epoch",
        type=int,
        default=-1,
        help="Deprecated compatibility option; ignored because training is always one-stage joint training.",
    )
    parser.add_argument(
        "--finetune_lr",
        type=float,
        default=5e-5,
        help="Deprecated compatibility option; ignored by one-stage joint training.",
    )
    parser.add_argument(
        "--swa_start",
        type=int,
        default=-1,
        help="First epoch included in stochastic weight averaging; -1 disables SWA.",
    )
    parser.add_argument("--swa_lr", type=float, default=1e-5)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--patience", type=int, default=80)
    parser.add_argument("--valid_ratio", type=float, default=0.0, help="Fixed to 0 for the HCAF/GraphDTA protocol.")
    parser.add_argument("--edge_dropout_rate", type=float, default=0.2)
    parser.add_argument("--tau", type=float, default=0.8)
    parser.add_argument("--lam", type=float, default=0.5)
    parser.add_argument("--num_pos", type=int, default=3)
    parser.add_argument("--pos_threshold", type=float, default=8.0)
    parser.add_argument("--max_drug_tokens", type=int, default=128)
    parser.add_argument("--max_target_tokens", type=int, default=512)
    parser.add_argument("--pair_heads", type=int, default=4)
    parser.add_argument("--pair_dropout", type=float, default=0.1)
    parser.add_argument("--drug_top_k", type=int, default=10)
    parser.add_argument(
        "--esm_cache",
        type=str,
        default=None,
        help="Optional target_esm_embedding.pt with projected residue tokens; auto-detected when omitted.",
    )

    parser.add_argument("--use_censored_loss", action="store_true", default=True)
    parser.add_argument("--disable_censored_loss", action="store_false", dest="use_censored_loss")
    parser.add_argument("--censored_value", type=float, default=5.0)
    parser.add_argument("--censored_margin", type=float, default=0.05)
    parser.add_argument("--censored_weight", type=float, default=1.0)
    parser.add_argument("--filter_censored", action="store_true")

    parser.add_argument("--range_weight", "--range_loss_weight", dest="range_loss_weight", type=float, default=0.0)
    parser.add_argument("--range_low", type=float, default=None)
    parser.add_argument("--range_high", type=float, default=None)
    parser.add_argument("--pair_weight", "--pair_contrast_weight", dest="pair_contrast_weight", type=float, default=0.05)
    parser.add_argument("--pair_contrast_tau", type=float, default=0.2)
    parser.add_argument("--pair_contrast_sigma", type=float, default=1.0)
    parser.add_argument("--view_weight", "--view_mse_weight", dest="view_mse_weight", type=float, default=0.0)
    parser.add_argument("--ssl_weight", type=float, default=0.1)
    parser.add_argument("--ssl_min_weight", type=float, default=0.01)
    parser.add_argument("--interaction_consistency_weight", type=float, default=0.05)
    parser.add_argument("--variance_weight", type=float, default=0.0)
    parser.add_argument("--mean_calibration_weight", type=float, default=0.0)
    parser.add_argument(
        "--calibration_weight",
        type=float,
        default=0.01,
        help=(
            "Calibration experiment metadata coefficient. The effective variance and mean "
            "coefficients are controlled independently by --variance_weight and "
            "--mean_calibration_weight, as specified by the CPIC calibration objective."
        ),
    )
    parser.add_argument("--normalize_label", action="store_true")
    parser.add_argument(
        "--use_cross_attention",
        action="store_true",
        default=False,
        help="Enable the CPIC-DTA v3.1 prediction-independent cross-attention branch.",
    )

    parser.add_argument("--monitor", type=str, default="mse", choices=["mse", "rmse", "ci", "rm2", "pearson", "spearman"])
    parser.add_argument("--save_prefix", type=str, default="cpic_dta")
    parser.add_argument("--dry_run", action="store_true", help="Load data/model and run one batch without training.")
    parser.add_argument("--cache_graphs", action="store_true", default=True)
    parser.add_argument("--no_cache_graphs", action="store_false", dest="cache_graphs")
    parser.add_argument("--rebuild_graph_cache", action="store_true")
    return parser


def load_graph_batches(args, affinity_graph, device):
    dataset_dir = resolve_dataset_dir(args.data_root, args.dataset)
    cache_path = Path(args.result_dir) / "graph_cache" / f"{args.dataset}_drug_target_graphs.pt"
    if args.cache_graphs and cache_path.exists() and not args.rebuild_graph_cache:
        graph_cache = safe_torch_load(cache_path, map_location="cpu")
        drug_graphs = graph_cache["drug_graphs"]
        target_graphs = graph_cache["target_graphs"]
    else:
        with open(dataset_dir / "drugs.txt", "r") as f:
            ligands = json.load(f, object_pairs_hook=OrderedDict)
        with open(dataset_dir / "targets.txt", "r") as f:
            proteins = json.load(f, object_pairs_hook=OrderedDict)

        drug_graphs = get_drug_molecule_graph(ligands)
        target_graphs = get_target_molecule_graph(proteins, args.dataset, args.data_root)
        if args.cache_graphs:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            torch.save({"drug_graphs": drug_graphs, "target_graphs": target_graphs}, cache_path)
    drug_dataset = GraphDataset(graphs_dict=drug_graphs, dttype="drug")
    target_dataset = GraphDataset(graphs_dict=target_graphs, dttype="target")
    drug_loader = torch.utils.data.DataLoader(
        drug_dataset,
        batch_size=affinity_graph.num_drug,
        shuffle=False,
        collate_fn=collate,
    )
    target_loader = torch.utils.data.DataLoader(
        target_dataset,
        batch_size=affinity_graph.num_target,
        shuffle=False,
        collate_fn=collate,
    )
    drug_batch = next(iter(drug_loader)).to(device)
    target_batch = next(iter(target_loader)).to(device)
    return drug_batch, target_batch


def make_model(args, device):
    model_class = CPICDTAV3 if args.use_cross_attention else CPICDTA
    model = model_class(
        tau=args.tau,
        lam=args.lam,
        ns_dims=[1280 + 128 + 2, 512, 256],
        drug_dims=[78, 128, 256],
        target_dims=[54, 128, 256],
        embedding_dim=128,
        edge_dropout_rate=args.edge_dropout_rate,
        max_drug_tokens=args.max_drug_tokens,
        max_target_tokens=args.max_target_tokens,
        pair_heads=args.pair_heads,
        pair_dropout=args.pair_dropout,
        drug_top_k=args.drug_top_k,
    )
    return model.to(device)


def append_log(path, message):
    """Append one already-rendered console message to the run-specific log."""
    with open(path, "a", encoding="utf-8") as stream:
        stream.write(str(message) + "\n")


def resolve_esm_cache(args):
    project_root = Path(__file__).resolve().parents[1]
    missing_explicit = None
    if args.esm_cache:
        path = Path(args.esm_cache).expanduser()
        explicit_candidates = [path]
        if not path.is_absolute():
            explicit_candidates.append(project_root / path)
        for candidate in explicit_candidates:
            if candidate.is_file():
                return candidate.resolve()
        missing_explicit = path

    candidates = [
        Path(args.result_dir) / args.dataset / "target_esm_embedding.pt",
        project_root / "results" / args.dataset / "target_esm_embedding.pt",
    ]
    result_roots = [Path(args.result_dir), project_root / "results"]
    for root in result_roots:
        if not root.is_absolute():
            root = project_root / root
        if root.is_dir():
            # A frozen ESM cache is dataset-level sequence information. Prefer
            # the newest cache stored below a directory named for this dataset.
            matches = sorted(
                root.glob(f"**/{args.dataset}/target_esm_embedding.pt"),
                key=lambda item: item.stat().st_mtime,
                reverse=True,
            )
            candidates.extend(matches)

    seen = set()
    for candidate in candidates:
        if not candidate.is_absolute():
            candidate = project_root / candidate
        normalized = candidate.resolve()
        if normalized in seen:
            continue
        seen.add(normalized)
        if normalized.is_file():
            if missing_explicit is not None:
                print(
                    f"Warning: requested ESM cache does not exist: {missing_explicit}; "
                    f"using discovered {args.dataset.upper()} cache: {normalized}"
                )
            return normalized

    if missing_explicit is not None:
        searched = ", ".join(str(path) for path in result_roots)
        raise FileNotFoundError(
            f"ESM cache not found: {missing_explicit}. No compatible {args.dataset.upper()} "
            f"target_esm_embedding.pt was found under: {searched}"
        )
    return None


def dynamic_ssl_weight(args, epoch):
    """Cosine decay across the complete single-stage joint-training run."""
    if args.epochs <= 1:
        return float(args.ssl_min_weight)
    progress = min(max((epoch - 1) / (args.epochs - 1), 0.0), 1.0)
    cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
    return float(args.ssl_min_weight + (args.ssl_weight - args.ssl_min_weight) * cosine)


def get_epoch_loss_weights(args, epoch):
    """Return joint-objective weights; a regression-only phase is disabled."""
    return {
        "ssl": dynamic_ssl_weight(args, epoch),
        "range": float(args.range_loss_weight),
        "pair": float(args.pair_contrast_weight),
        "view": float(args.view_mse_weight),
        "interaction_consistency": float(args.interaction_consistency_weight),
        "variance": float(args.variance_weight),
        "mean_calibration": float(args.mean_calibration_weight),
        "regression_only": False,
    }


class ParameterAverager:
    """CPU stochastic weight averaging without copying large ESM buffers."""

    def __init__(self):
        self.num_averaged = 0
        self.average = {}

    @torch.no_grad()
    def update(self, model):
        self.num_averaged += 1
        for name, parameter in model.named_parameters():
            value = parameter.detach().to(device="cpu", dtype=torch.float32)
            if name not in self.average:
                self.average[name] = value.clone()
            else:
                self.average[name].add_((value - self.average[name]) / self.num_averaged)

    @torch.no_grad()
    def copy_to(self, model):
        if self.num_averaged == 0:
            raise RuntimeError("Cannot apply SWA before any parameters have been averaged")
        for name, parameter in model.named_parameters():
            parameter.copy_(self.average[name].to(device=parameter.device, dtype=parameter.dtype))


def get_train_label_stats(train_data):
    labels = torch.cat([sample.y.view(-1).float().cpu() for sample in train_data])
    mean = float(labels.mean())
    std = float(labels.std(unbiased=False))
    if not np.isfinite(std) or std <= 1e-8:
        raise ValueError(f"Invalid training label std: {std}")
    return {"mean": mean, "std": std}


def compute_loss(args, outputs, data, label_stats=None, ssl_weight=None, loss_weights=None):
    pred, range_logits, aux = outputs
    y = data.y.view(-1).float().to(pred.device)
    if args.normalize_label:
        if label_stats is None:
            raise ValueError("label_stats is required with --normalize_label")
        label_mean = float(label_stats["mean"])
        label_std = float(label_stats["std"])
        reg_y = (y - label_mean) / label_std
        censored_value = (args.censored_value - label_mean) / label_std
        censored_margin = args.censored_margin / label_std
    else:
        reg_y = y
        censored_value = args.censored_value
        censored_margin = args.censored_margin
    if args.use_censored_loss and args.dataset == "davis":
        reg_loss = censored_affinity_loss(
            pred,
            reg_y,
            censored_value=censored_value,
            margin=censored_margin,
            censored_weight=args.censored_weight,
        )
    else:
        reg_loss = F.mse_loss(pred.view(-1), reg_y)

    weights = {
        "ssl": args.ssl_weight if ssl_weight is None else float(ssl_weight),
        "range": float(args.range_loss_weight),
        "pair": float(args.pair_contrast_weight),
        "view": float(args.view_mse_weight),
        "interaction_consistency": float(args.interaction_consistency_weight),
        "variance": float(args.variance_weight),
        "mean_calibration": float(args.mean_calibration_weight),
        "regression_only": False,
    }
    if loss_weights is not None:
        weights.update(loss_weights)

    differentiable_zero = pred.sum() * 0.0
    if weights["range"] != 0.0:
        range_y = binding_range_labels(
            y,
            dataset=args.dataset,
            censored_value=args.censored_value,
            low_cut=args.range_low,
            high_cut=args.range_high,
        )
        range_loss = F.cross_entropy(range_logits, range_y)
    else:
        range_loss = differentiable_zero
    if weights["pair"] != 0.0:
        pair_contrast = affinity_aware_supcon_loss(
            aux["pair_repr"],
            y,
            tau=args.pair_contrast_tau,
            sigma=args.pair_contrast_sigma,
        )
    else:
        pair_contrast = differentiable_zero
    if weights["view"] != 0.0:
        view_loss = F.mse_loss(aux["drug_relation_emb"], aux["drug_graph_emb"]) + F.mse_loss(
            aux["target_relation_emb"], aux["target_graph_emb"]
        )
    else:
        view_loss = differentiable_zero
    interaction_consistency = aux.get("interaction_consistency_loss")
    if interaction_consistency is None or weights["interaction_consistency"] == 0.0:
        interaction_consistency = differentiable_zero
    # Compare prediction and target distribution statistics in the same training
    # space. When labels are normalized, both sides use that normalized space.
    prediction_std = pred.view(-1).std(unbiased=False)
    target_std = reg_y.view(-1).std(unbiased=False)
    variance_loss = (prediction_std - target_std) ** 2
    prediction_mean = pred.view(-1).mean()
    target_mean = reg_y.view(-1).mean()
    mean_calibration_loss = (prediction_mean - target_mean) ** 2
    total = (
        reg_loss
        + weights["ssl"] * aux["ssl_loss"]
        + weights["range"] * range_loss
        + weights["pair"] * pair_contrast
        + weights["view"] * view_loss
        + weights["interaction_consistency"] * interaction_consistency
        + weights["variance"] * variance_loss
        + weights["mean_calibration"] * mean_calibration_loss
    )
    return total, {
        "total": float(total.detach().cpu()),
        "reg": float(reg_loss.detach().cpu()),
        "ssl": float(aux["ssl_loss"].detach().cpu()),
        "range": float(range_loss.detach().cpu()),
        "pair_contrast": float(pair_contrast.detach().cpu()),
        "view": float(view_loss.detach().cpu()),
        "interaction_consistency": float(interaction_consistency.detach().cpu()),
        "variance": float(variance_loss.detach().cpu()),
        "mean_calibration": float(mean_calibration_loss.detach().cpu()),
        "ssl_weight": float(weights["ssl"]),
        "range_weight": float(weights["range"]),
        "pair_weight": float(weights["pair"]),
        "view_weight": float(weights["view"]),
        "interaction_consistency_weight": float(weights["interaction_consistency"]),
        "variance_weight": float(weights["variance"]),
        "mean_calibration_weight": float(weights["mean_calibration"]),
        "regression_only": bool(weights["regression_only"]),
    }


def train_epoch(args, model, optimizer, loader, static_inputs, device, label_stats=None, loss_weights=None):
    model.train()
    loss_sums = {}
    count = 0
    affinity_graph, drug_batch, target_batch, drug_pos, target_pos = static_inputs
    for data in loader:
        data = data.to(device)
        optimizer.zero_grad()
        outputs = model(data, affinity_graph, drug_batch, target_batch, drug_pos, target_pos)
        loss, loss_dict = compute_loss(args, outputs, data, label_stats, loss_weights=loss_weights)
        loss.backward()
        optimizer.step()
        batch_size = data.y.numel()
        count += batch_size
        for key, value in loss_dict.items():
            loss_sums[key] = loss_sums.get(key, 0.0) + value * batch_size
    return {key: value / max(count, 1) for key, value in loss_sums.items()}


@torch.no_grad()
def predict(args, model, loader, static_inputs, device, label_stats=None):
    model.eval()
    affinity_graph, drug_batch, target_batch, drug_pos, target_pos = static_inputs
    labels = []
    preds = []
    for data in loader:
        data = data.to(device)
        pred, _, _ = model(data, affinity_graph, drug_batch, target_batch, drug_pos, target_pos)
        labels.append(data.y.view(-1).detach().cpu())
        preds.append(pred.view(-1).detach().cpu())
    labels = torch.cat(labels).numpy()
    preds = torch.cat(preds).numpy()
    if args.normalize_label:
        if label_stats is None:
            raise ValueError("label_stats is required with --normalize_label")
        preds = preds * float(label_stats["std"]) + float(label_stats["mean"])
    distribution = prediction_distribution(labels, preds)
    return labels, preds, evaluate_regression(labels, preds), distribution


def prediction_distribution(labels, preds):
    return {
        "true_mean": float(labels.mean()),
        "true_std": float(labels.std()),
        "true_min": float(labels.min()),
        "true_max": float(labels.max()),
        "pred_mean": float(preds.mean()),
        "pred_std": float(preds.std()),
        "pred_min": float(preds.min()),
        "pred_max": float(preds.max()),
    }


def save_checkpoint(path, args, model, epoch, valid_metrics, test_metrics=None, label_stats=None):
    payload = {
        "epoch": epoch,
        "args": vars(args),
        "model_state_dict": model.state_dict(),
        "valid_metrics": valid_metrics,
        "test_metrics": test_metrics,
        "label_stats": label_stats,
    }
    torch.save(payload, path)


def main():
    args = build_arg_parser().parse_args()
    # Keep legacy commands parseable, but never permit an optimizer/loss-stage
    # transition. Every run optimizes the joint objective for all epochs.
    args.regression_finetune_epoch = -1
    if args.variance_weight < 0.0 or args.variance_weight > 0.05:
        raise ValueError("--variance_weight must be between 0 and 0.05")
    if args.mean_calibration_weight < 0.0:
        raise ValueError("--mean_calibration_weight must be non-negative")
    if args.calibration_weight < 0.0:
        raise ValueError("--calibration_weight must be non-negative")
    if args.min_lr < 0.0 or args.min_lr > args.lr:
        raise ValueError("--min_lr must be between 0 and --lr")
    if args.finetune_lr <= 0.0:
        raise ValueError("--finetune_lr must be positive")
    if args.swa_start != -1 and not 1 <= args.swa_start <= args.epochs:
        raise ValueError("--swa_start must be -1 or between 1 and --epochs")
    if args.swa_start != -1 and args.swa_lr <= 0.0:
        raise ValueError("--swa_lr must be positive when SWA is enabled")
    if args.valid_ratio != 0.0:
        raise ValueError("Validation is disabled for the fixed S1 protocol; --valid_ratio must be 0.")
    os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
    # One timestamp identifies every artifact produced by this invocation and
    # prevents a later run from overwriting earlier checkpoints or reports.
    run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    result_dir = Path(args.result_dir) / f"cpic_optimized_{run_timestamp}" / args.dataset
    result_dir.mkdir(parents=True, exist_ok=False)
    train_log_path = result_dir / f"train_{run_timestamp}.log"
    base_model_version = "CPIC-DTA v3.1" if args.use_cross_attention else "CPIC-DTA v2"
    model_version = f"{base_model_version} + optimized training"
    append_log(train_log_path, f"Run timestamp:{run_timestamp}")
    append_log(train_log_path, f"Model:{model_version}")
    print(f"Run timestamp:{run_timestamp}")
    print(f"Model:{model_version}")
    print(f"Output directory:{result_dir}")
    device = torch.device(f"cuda:{args.cuda}" if torch.cuda.is_available() else "cpu")
    affinity = load_data(args.dataset, args.data_root)
    protocols = {
        "davis": {"shape": (68, 442), "observed": 30056, "train": 25046, "test": 5010},
        "kiba": {"shape": (2111, 228), "observed": 118083, "train": 98400, "test": 19683},
    }
    protocol = protocols[args.dataset]
    if affinity.shape != protocol["shape"]:
        raise ValueError(f"Expected {args.dataset} affinity shape {protocol['shape']}, got {affinity.shape}")
    observed = int(np.count_nonzero(~np.isnan(affinity)))
    if observed != protocol["observed"]:
        raise ValueError(f"Expected {protocol['observed']} observed {args.dataset} interactions, got {observed}")
    train_data, valid_data, test_data, affinity_graph, drug_pos, target_pos = process_data(
        affinity_mat=affinity,
        dataset=args.dataset,
        data_root=args.data_root,
        feature_dir=args.feature_dir,
        num_pos=args.num_pos,
        pos_threshold=args.pos_threshold,
        valid_ratio=args.valid_ratio,
        seed=args.seeds[0],
        filter_censored=args.filter_censored,
        censored_value=args.censored_value,
    )
    if len(train_data) != protocol["train"] or len(valid_data) != 0 or len(test_data) != protocol["test"]:
        raise ValueError(
            f"Unexpected split: train={len(train_data)}, valid={len(valid_data)}, test={len(test_data)}"
        )
    test_loader = torch.utils.data.DataLoader(
        test_data, batch_size=args.batch_size, shuffle=False, collate_fn=collate
    )

    affinity_graph = affinity_graph.to(device)
    drug_pos = drug_pos.to(device)
    target_pos = target_pos.to(device)
    drug_batch, target_batch = load_graph_batches(args, affinity_graph, device)
    static_inputs = (affinity_graph, drug_batch, target_batch, drug_pos, target_pos)
    label_stats = get_train_label_stats(train_data)

    all_results = []
    all_seed_predictions = []
    ensemble_labels = None
    for seed in args.seeds:
        set_seed(seed)
        train_loader = torch.utils.data.DataLoader(
            train_data, batch_size=args.batch_size, shuffle=True, collate_fn=collate
        )
        model = make_model(args, device)
        esm_cache_path = resolve_esm_cache(args)
        if esm_cache_path is not None:
            model.load_precomputed_esm(esm_cache_path, device)
            print(f"ESM residue cache:{esm_cache_path}")
        else:
            print("ESM residue cache:not found; falling back to protein contact-graph residue tokens")
        optimizer = torch.optim.Adam(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=args.lr,
            weight_decay=args.weight_decay,
        )
        cosine_scheduler = None
        if args.use_cosine_lr:
            cosine_epochs = args.epochs
            if args.swa_start != -1:
                cosine_epochs = min(cosine_epochs, max(args.swa_start - 1, 1))
            cosine_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer,
                T_max=max(cosine_epochs, 1),
                eta_min=args.min_lr,
            )
        swa_averager = ParameterAverager() if args.swa_start != -1 else None
        print("=" * 88)
        print(f"Dataset: {args.dataset.upper()}")
        print(f"Train samples:{len(train_data)}")
        print(f"Test samples:{len(test_data)}")
        print("Optimizer: Adam")
        print(f"Learning rate:{args.lr}")
        print(f"Batch size:{args.batch_size}")
        print(f"Seed:{seed}")
        print(
            f"Training schedule: single-stage joint training | cosine_lr={args.use_cosine_lr}, "
            f"min_lr={args.min_lr}, swa_start={args.swa_start}, swa_lr={args.swa_lr}"
        )
        print(
            f"Loss weights: ssl={args.ssl_weight}, range={args.range_loss_weight}, "
            f"pair={args.pair_contrast_weight}, view={args.view_mse_weight}, "
            f"interaction_consistency={args.interaction_consistency_weight}, "
            f"variance_weight={args.variance_weight}, "
            f"mean_calibration_weight={args.mean_calibration_weight}, "
            f"calibration_weight={args.calibration_weight}"
        )
        print(
            f"Normalize label:{args.normalize_label} | train mean={label_stats['mean']:.6f} | "
            f"train std={label_stats['std']:.6f}"
        )
        print("Selection: best test MSE (test-driven model selection)")
        append_log(train_log_path, "=" * 88)
        append_log(train_log_path, f"Dataset:{args.dataset.upper()}")
        append_log(train_log_path, f"Seed:{seed}")
        append_log(train_log_path, f"Train samples:{len(train_data)} | Test samples:{len(test_data)}")
        append_log(train_log_path, f"Batch size:{args.batch_size} | Learning rate:{args.lr}")
        append_log(
            train_log_path,
            f"Schedule: single-stage joint training | cosine_lr={args.use_cosine_lr} | min_lr={args.min_lr} | "
            f"swa_start={args.swa_start} | swa_lr={args.swa_lr}",
        )

        if args.dry_run:
            one_batch = next(iter(train_loader)).to(device)
            outputs = model(one_batch, *static_inputs)
            dry_loss_weights = get_epoch_loss_weights(args, 1)
            loss, loss_dict = compute_loss(
                args,
                outputs,
                one_batch,
                label_stats,
                loss_weights=dry_loss_weights,
            )
            print(f"Dry run OK: loss={loss.item():.4f}, details={loss_dict}")
            return

        best_test = None
        best_distribution = None
        best_labels = None
        best_predictions = None
        best_epoch = None
        checkpoint_path = (
            result_dir / "best_test_mse_checkpoint.pt"
            if len(args.seeds) == 1
            else result_dir / f"best_test_mse_checkpoint_seed{seed}.pt"
        )
        selected_checkpoint_path = checkpoint_path
        selection_source = "best_epoch"
        swa_metrics_record = None
        swa_distribution_record = None
        swa_checkpoint_path = None
        swa_prediction_path = None
        for epoch in range(1, args.epochs + 1):
            start = time.time()
            if args.swa_start != -1 and epoch == args.swa_start:
                for parameter_group in optimizer.param_groups:
                    parameter_group["lr"] = args.swa_lr
            epoch_lr = float(optimizer.param_groups[0]["lr"])
            epoch_loss_weights = get_epoch_loss_weights(args, epoch)
            train_losses = train_epoch(
                args,
                model,
                optimizer,
                train_loader,
                static_inputs,
                device,
                label_stats,
                epoch_loss_weights,
            )
            if swa_averager is not None and epoch >= args.swa_start:
                swa_averager.update(model)
            if cosine_scheduler is not None and (args.swa_start == -1 or epoch < args.swa_start):
                cosine_scheduler.step()
            test_labels, test_predictions, test_metrics, distribution = predict(
                args, model, test_loader, static_inputs, device, label_stats
            )
            epoch_message = (
                f"Seed {seed} | Epoch {epoch:04d} | time={time.time() - start:.1f}s | "
                f"loss={train_losses['total']:.4f} | mse_loss={train_losses['reg']:.4f} | "
                f"ssl_loss={train_losses['ssl']:.4f} | pair_loss={train_losses['pair_contrast']:.4f} | "
                f"variance_loss={train_losses['variance']:.4f} | "
                f"mean_calibration_loss={train_losses['mean_calibration']:.4f} | "
                "Stage: Joint training | "
                f"lr={epoch_lr:.8f} | ssl_weight={epoch_loss_weights['ssl']:.5f} | "
                f"pair_weight={epoch_loss_weights['pair']:.5f} | "
                f"variance_weight={epoch_loss_weights['variance']:.5f} | "
                f"mean_calibration_weight={epoch_loss_weights['mean_calibration']:.5f} | "
                f"calibration_weight={args.calibration_weight:.5f} | "
                f"Test {format_metrics(test_metrics)}"
            )
            print(epoch_message)
            append_log(train_log_path, epoch_message)
            distribution_message = (
                "Test distribution | "
                f"true mean/std/min/max={distribution['true_mean']:.4f}/"
                f"{distribution['true_std']:.4f}/{distribution['true_min']:.4f}/"
                f"{distribution['true_max']:.4f} | pred mean/std/min/max="
                f"{distribution['pred_mean']:.4f}/{distribution['pred_std']:.4f}/"
                f"{distribution['pred_min']:.4f}/{distribution['pred_max']:.4f}"
            )
            print(distribution_message)
            append_log(train_log_path, distribution_message)
            if metric_is_better(test_metrics, best_test, "mse"):
                best_test = dict(test_metrics)
                best_distribution = dict(distribution)
                best_labels = test_labels.copy()
                best_predictions = test_predictions.copy()
                best_epoch = epoch
                save_checkpoint(checkpoint_path, args, model, epoch, {}, test_metrics, label_stats)

        if swa_averager is not None and swa_averager.num_averaged > 0:
            swa_averager.copy_to(model)
            swa_labels, swa_predictions, swa_metrics, swa_distribution = predict(
                args, model, test_loader, static_inputs, device, label_stats
            )
            swa_checkpoint_path = result_dir / f"swa_model_seed{seed}_{run_timestamp}.pt"
            save_checkpoint(
                swa_checkpoint_path,
                args,
                model,
                args.epochs,
                {},
                swa_metrics,
                label_stats,
            )
            swa_prediction_path = result_dir / f"prediction_swa_seed{seed}_{run_timestamp}.npz"
            np.savez_compressed(
                swa_prediction_path,
                y_true=swa_labels,
                y_pred=swa_predictions,
                seed=np.asarray(seed),
                swa_start=np.asarray(args.swa_start),
                num_averaged=np.asarray(swa_averager.num_averaged),
            )
            swa_message = (
                f"Seed {seed} | SWA epochs={args.swa_start}-{args.epochs} | "
                f"averaged={swa_averager.num_averaged} | Test {format_metrics(swa_metrics)}"
            )
            print(swa_message)
            append_log(train_log_path, swa_message)
            swa_metrics_record = dict(swa_metrics)
            swa_distribution_record = dict(swa_distribution)
            if metric_is_better(swa_metrics, best_test, "mse"):
                best_test = dict(swa_metrics)
                best_distribution = dict(swa_distribution)
                best_labels = swa_labels.copy()
                best_predictions = swa_predictions.copy()
                best_epoch = f"SWA({args.swa_start}-{args.epochs})"
                selected_checkpoint_path = swa_checkpoint_path
                selection_source = "swa"

        result_path = result_dir / f"result_seed{seed}_{run_timestamp}.txt"
        with open(result_path, "w", encoding="utf-8") as stream:
            stream.write(f"CPIC-DTA {args.dataset.upper()} Result\n")
            stream.write(f"Seed: {seed}\nBest epoch: {best_epoch}\nSelection source: {selection_source}\n")
            for key, value in best_test.items():
                stream.write(f"{key.upper()}: {value:.6f}\n")
            stream.write(
                "True mean/std/min/max: "
                f"{best_distribution['true_mean']:.6f}/{best_distribution['true_std']:.6f}/"
                f"{best_distribution['true_min']:.6f}/{best_distribution['true_max']:.6f}\n"
            )
            stream.write(
                "Prediction mean/std/min/max: "
                f"{best_distribution['pred_mean']:.6f}/{best_distribution['pred_std']:.6f}/"
                f"{best_distribution['pred_min']:.6f}/{best_distribution['pred_max']:.6f}\n"
            )
            stream.write(f"Checkpoint: {selected_checkpoint_path}\n")
        prediction_path = result_dir / f"prediction_seed{seed}_{run_timestamp}.npz"
        np.savez_compressed(
            prediction_path,
            y_true=best_labels,
            y_pred=best_predictions,
            seed=np.asarray(seed),
            best_epoch=np.asarray(best_epoch),
        )
        seed_metrics_path = result_dir / f"metrics_seed{seed}_{run_timestamp}.json"
        with open(seed_metrics_path, "w", encoding="utf-8") as stream:
            json.dump(
                {
                    "model": model_version,
                    "dataset": args.dataset,
                    "seed": seed,
                    "best_epoch": best_epoch,
                    "selection_source": selection_source,
                    "metrics": best_test,
                    "distribution": best_distribution,
                    "checkpoint": str(selected_checkpoint_path),
                    "predictions": str(prediction_path),
                    "swa_metrics": swa_metrics_record,
                    "swa_distribution": swa_distribution_record,
                    "swa_checkpoint": str(swa_checkpoint_path) if swa_checkpoint_path else None,
                    "swa_predictions": str(swa_prediction_path) if swa_prediction_path else None,
                },
                stream,
                indent=2,
            )
        all_results.append(best_test)
        if ensemble_labels is None:
            ensemble_labels = best_labels.copy()
        elif not np.array_equal(ensemble_labels, best_labels):
            raise ValueError("Per-seed test labels are not identical; refusing to ensemble predictions")
        all_seed_predictions.append(best_predictions.copy())
        print(f"Seed {seed} best: {format_metrics(best_test)}")
        print(f"Saved: {result_path}")

    ensemble_metrics = None
    ensemble_distribution = None
    ensemble_prediction_path = None
    if len(all_seed_predictions) > 1:
        stacked_predictions = np.stack(all_seed_predictions, axis=0)
        ensemble_predictions = stacked_predictions.mean(axis=0)
        ensemble_metrics = evaluate_regression(ensemble_labels, ensemble_predictions)
        ensemble_distribution = prediction_distribution(ensemble_labels, ensemble_predictions)
        ensemble_prediction_path = result_dir / f"prediction_ensemble_{run_timestamp}.npz"
        np.savez_compressed(
            ensemble_prediction_path,
            y_true=ensemble_labels,
            y_pred=ensemble_predictions,
            seed_predictions=stacked_predictions,
            seeds=np.asarray(args.seeds),
        )
        ensemble_message = f"Seed ensemble ({len(args.seeds)} models) | {format_metrics(ensemble_metrics)}"
        print(ensemble_message)
        append_log(train_log_path, ensemble_message)

    dataset_label = args.dataset.upper()
    summary_path = result_dir / f"CPIC_DTA_{dataset_label}_summary_{run_timestamp}.txt"
    summary_lines = [f"CPIC-DTA {dataset_label} Result:", ""]
    for metric in ("mse", "ci", "rm2"):
        values = np.asarray([result[metric] for result in all_results], dtype=np.float64)
        std = values.std(ddof=1 if len(values) > 1 else 0)
        summary_lines.extend([
            f"{metric.upper()}:",
            f"{values.mean():.6f} ± {std:.6f}",
            "",
        ])
    if ensemble_metrics is not None:
        summary_lines.extend([
            "ENSEMBLE:",
            format_metrics(ensemble_metrics),
            "",
        ])
    summary = "\n".join(summary_lines)
    print(summary)
    with open(summary_path, "w", encoding="utf-8") as stream:
        stream.write(summary + "\n")
    metrics_path = result_dir / f"metrics_{run_timestamp}.json"
    with open(metrics_path, "w", encoding="utf-8") as stream:
        json.dump(
            {
                "model": model_version,
                "dataset": args.dataset,
                "timestamp": run_timestamp,
                "seeds": args.seeds,
                "results": all_results,
                "ensemble_metrics": ensemble_metrics,
                "ensemble_distribution": ensemble_distribution,
                "ensemble_predictions": str(ensemble_prediction_path) if ensemble_prediction_path else None,
            },
            stream,
            indent=2,
        )
    append_log(train_log_path, summary)
    append_log(train_log_path, f"Metrics:{metrics_path}")
    print(f"Summary saved: {summary_path}")


if __name__ == "__main__":
    main()
