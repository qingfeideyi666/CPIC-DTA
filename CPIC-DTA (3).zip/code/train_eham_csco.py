"""Training entry point for EHAM-CSCoDTA on Davis and KIBA."""

# NEW MODULE

from __future__ import annotations

import argparse
import json
import os
import random
import time
from collections import OrderedDict
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from tqdm.auto import tqdm

from data_process import get_drug_molecule_graph, get_target_molecule_graph, load_data, process_data, resolve_dataset_dir
from embedding_cache import EpochEmbeddingCache
from esm_encoder import ESM2_BASE, ESM2_SMALL
from models_eham_csco import EHAM_CSCoDTA
from utils import GraphDataset, collate, evaluate_regression, format_metrics


def set_seed(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def parser():
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description="Train EHAM-CSCoDTA")
    p.add_argument("--dataset", choices=("davis", "kiba"), default="davis")
    p.add_argument("--data_root", default=os.environ.get("EHAM_DATA_ROOT", str(root / "data")))
    p.add_argument("--feature_dir", default=os.environ.get("EHAM_FEATURE_DIR", str(root / "features")))
    p.add_argument("--result_dir", default=str(root / "results")); p.add_argument("--cuda", type=int, default=0)
    p.add_argument("--seed", type=int, default=2025); p.add_argument("--epochs", type=int, default=500)
    p.add_argument("--batch_size", type=int, default=128); p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--weight_decay", type=float, default=0.0); p.add_argument("--valid_ratio", type=float, default=.1)
    p.add_argument("--num_pos", type=int, default=3); p.add_argument("--pos_threshold", type=float, default=8.0)
    p.add_argument("--hidden_dim", type=int, default=256); p.add_argument("--edge_dropout", type=float, default=.2)
    p.add_argument("--max_drug_tokens", type=int, default=128); p.add_argument("--max_target_tokens", type=int, default=512)
    p.add_argument("--esm_size", choices=("small", "base"), default="small")
    p.add_argument("--esm_model", default=None); p.add_argument("--esm_backend", choices=("esm2", "fallback"), default="esm2")
    p.add_argument("--freeze_esm", action="store_true", default=True)
    p.add_argument("--no_freeze_esm", action="store_false", dest="freeze_esm")
    p.add_argument("--precompute_esm", action="store_true", help="Generate target_esm_embedding.pt and exit")
    p.add_argument("--rebuild_esm_cache", action="store_true")
    p.add_argument("--esm_precompute_batch_size", type=int, default=4)
    p.add_argument("--contrastive_weight", type=float, default=.1)
    p.add_argument("--view_consistency_weight", type=float, default=.1)
    p.add_argument("--alignment_weight", type=float, default=.1)
    p.add_argument("--dry_run", action="store_true")
    p.add_argument("--run_name", default=None, help="Unique experiment name; defaults to a timestamp")
    return p


def load_static(args, affinity_graph, device):
    dataset_dir = resolve_dataset_dir(args.data_root, args.dataset)
    with open(dataset_dir / "drugs.txt", encoding="utf-8") as f:
        ligands = json.load(f, object_pairs_hook=OrderedDict)
    with open(dataset_dir / "targets.txt", encoding="utf-8") as f:
        proteins = json.load(f, object_pairs_hook=OrderedDict)
    drug_dict = get_drug_molecule_graph(ligands)
    protein_dict = get_target_molecule_graph(proteins, args.dataset, args.data_root)
    drug_dataset = GraphDataset(graphs_dict=drug_dict, dttype="drug")
    protein_dataset = GraphDataset(graphs_dict=protein_dict, dttype="target")
    drug_batch = collate([drug_dataset[i] for i in range(len(drug_dataset))]).to(device)
    protein_batch = collate([protein_dataset[i] for i in range(len(protein_dataset))]).to(device)
    return drug_batch, protein_batch, list(proteins.values())


def compute_loss(args, prediction, aux, labels):
    affinity_loss = F.mse_loss(prediction.view(-1), labels.view(-1))
    total_loss = affinity_loss + args.contrastive_weight * aux["contrastive_loss"] + \
        args.view_consistency_weight * aux["view_consistency_loss"] + args.alignment_weight * aux["alignment_loss"]
    values = {"total": total_loss, "affinity": affinity_loss, "contrastive": aux["contrastive_loss"],
              "view_consistency": aux["view_consistency_loss"], "alignment": aux["alignment_loss"]}
    return total_loss, {k: float(v.detach().cpu()) for k, v in values.items()}


def run_epoch(args, model, loader, static, device, optimizer=None):
    """Build one differentiable entity cache, then stream pair batches through the predictor."""
    training = optimizer is not None
    model.train(training)
    context = torch.enable_grad() if training else torch.no_grad()
    totals, seen = {}, 0
    with context:
        if training:
            optimizer.zero_grad(set_to_none=True)
        cache = EpochEmbeddingCache.build(model, *static)
        aux = cache.auxiliary
        static_loss = args.contrastive_weight * aux["contrastive_loss"] + \
            args.view_consistency_weight * aux["view_consistency_loss"] + \
            args.alignment_weight * aux["alignment_loss"]
        batch_count = 1 if args.dry_run else len(loader)
        sample_count = min(len(loader.dataset), args.batch_size) if args.dry_run else len(loader.dataset)
        progress = tqdm(loader, total=batch_count, desc="Train", unit="batch", dynamic_ncols=True)
        for batch_index, pairs in enumerate(progress):
            if batch_index >= batch_count:
                break
            pairs = pairs.to(device, non_blocking=True)
            prediction, _ = model.predict_from_cache(pairs, cache)
            affinity_loss = F.mse_loss(prediction.view(-1), pairs.y.float().to(device).view(-1))
            size = pairs.y.numel(); seen += size
            is_last = batch_index + 1 == batch_count
            if training:
                objective = affinity_loss * (size / max(sample_count, 1))
                if is_last:
                    objective = objective + static_loss
                objective.backward(retain_graph=not is_last)
            totals["affinity"] = totals.get("affinity", 0.0) + float(affinity_loss.detach().cpu()) * size
            progress.set_postfix(loss=f"{float(affinity_loss.detach().cpu()):.4f}")
        progress.close()
        if training:
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
    result = {
        "affinity": totals["affinity"] / max(seen, 1),
        "contrastive": float(aux["contrastive_loss"].detach().cpu()),
        "view_consistency": float(aux["view_consistency_loss"].detach().cpu()),
        "alignment": float(aux["alignment_loss"].detach().cpu()),
    }
    result["total"] = result["affinity"] + args.contrastive_weight * result["contrastive"] + \
        args.view_consistency_weight * result["view_consistency"] + args.alignment_weight * result["alignment"]
    return result


@torch.no_grad()
def test(model, loader, static, device, description="Eval"):
    model.eval(); labels, predictions = [], []
    cache = EpochEmbeddingCache.build(model, *static).detached()
    total = 1 if getattr(model, "_dry_run", False) else len(loader)
    progress = tqdm(loader, total=total, desc=description, unit="batch", dynamic_ncols=True, leave=False)
    for batch_index, pairs in enumerate(progress):
        pairs = pairs.to(device, non_blocking=True); pred, _ = model.predict_from_cache(pairs, cache)
        labels.append(pairs.y.view(-1).cpu()); predictions.append(pred.view(-1).cpu())
        if getattr(model, "_dry_run", False):
            break
    progress.close()
    y, p = torch.cat(labels).numpy(), torch.cat(predictions).numpy()
    return evaluate_regression(y, p)


@torch.no_grad()
def benchmark_schedules(model, loader, static, device, batches=2):
    """Estimate full-epoch old/new time from encoder and two predictor batches."""
    model.eval()
    selected = []
    for index, pairs in enumerate(loader):
        selected.append(pairs.to(device))
        if index + 1 >= batches:
            break
    if device.type == "cuda": torch.cuda.synchronize(device)
    start = time.perf_counter()
    cache = EpochEmbeddingCache.build(model, *static)
    if device.type == "cuda": torch.cuda.synchronize(device)
    encode_seconds = time.perf_counter() - start
    start = time.perf_counter()
    for pairs in selected:
        model.predict_from_cache(pairs, cache)
    if device.type == "cuda": torch.cuda.synchronize(device)
    predict_per_batch = (time.perf_counter() - start) / max(len(selected), 1)
    total_batches = len(loader)
    before_epoch = total_batches * (encode_seconds + predict_per_batch)
    after_epoch = encode_seconds + total_batches * predict_per_batch
    return before_epoch, after_epoch


def main():
    args = parser().parse_args(); set_seed(args.seed)
    if args.dataset == "kiba" and args.num_pos == 3: args.num_pos = 10
    device = torch.device(f"cuda:{args.cuda}" if torch.cuda.is_available() else "cpu")
    out = Path(args.result_dir) / args.dataset; out.mkdir(parents=True, exist_ok=True)
    run_name = args.run_name or datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = out / "runs" / run_name
    if run_dir.exists():
        raise FileExistsError(f"Run directory already exists: {run_dir}. Choose another --run_name.")
    run_dir.mkdir(parents=True)
    metrics_path = run_dir / "metrics.jsonl"
    affinity = load_data(args.dataset, args.data_root)
    train_set, valid_set, test_set, affinity_graph, drug_pos, target_pos = process_data(
        affinity, args.dataset, args.data_root, args.feature_dir, args.num_pos, args.pos_threshold,
        args.valid_ratio, args.seed,
    )
    loaders = [torch.utils.data.DataLoader(ds, batch_size=args.batch_size, shuffle=(i == 0), collate_fn=collate)
               for i, ds in enumerate((train_set, valid_set, test_set))]
    affinity_graph, drug_pos, target_pos = affinity_graph.to(device), drug_pos.to(device), target_pos.to(device)
    drug_batch, protein_batch, sequences = load_static(args, affinity_graph, device)
    esm_model = args.esm_model or (ESM2_SMALL if args.esm_size == "small" else ESM2_BASE)
    if not args.freeze_esm:
        raise ValueError("Training-time ESM forward is disabled. Use --freeze_esm with precompute mode.")
    model = EHAM_CSCoDTA(
        affinity_input_dim=affinity_graph.x.size(1), hidden_dim=args.hidden_dim,
        max_drug_tokens=args.max_drug_tokens, max_target_tokens=args.max_target_tokens,
        esm_model=esm_model, freeze_esm=True, esm_backend=args.esm_backend,
        edge_dropout=args.edge_dropout,
    ).to(device)
    esm_cache_path = out / "target_esm_embedding.pt"
    cache_valid = False
    if esm_cache_path.exists() and not args.rebuild_esm_cache:
        try:
            cached = torch.load(esm_cache_path, map_location="cpu", weights_only=False)
        except TypeError:
            cached = torch.load(esm_cache_path, map_location="cpu")
        cache_valid = cached.get("model_name") == esm_model and cached.get("backend") == args.esm_backend and \
            cached.get("sequence_count") == len(sequences) and cached.get("max_length") == args.max_target_tokens
    if not cache_valid:
        print(f"Precomputing frozen ESM embeddings -> {esm_cache_path}", flush=True)
        model.esm_encoder.precompute(
            sequences, esm_cache_path, device, args.esm_backend, args.esm_precompute_batch_size
        )
    if args.precompute_esm:
        print(f"ESM precompute complete: {esm_cache_path}")
        return
    payload = model.load_precomputed_esm(esm_cache_path, device)
    if payload.get("sequence_count") != len(sequences):
        raise ValueError("ESM cache sequence count does not match targets.txt")
    static = (affinity_graph, drug_batch, protein_batch, drug_pos, target_pos)
    model._dry_run = args.dry_run
    optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad), lr=args.lr,
                                  weight_decay=args.weight_decay)
    print(f"EHAM-CSCoDTA | {args.dataset} | {device} | ESM cache={esm_cache_path} | frozen=True")
    before, after = benchmark_schedules(model, loaders[0], static, device, batches=2)
    print(f"Estimated epoch time | before={before:.3f}s | after={after:.3f}s | speedup={before/max(after,1e-9):.2f}x")
    best_mse = float("inf"); best_path = run_dir / "best_model.pt"
    for epoch in range(1, args.epochs + 1):
        start = time.time(); losses = run_epoch(args, model, loaders[0], static, device, optimizer)
        valid_metrics = test(model, loaders[1], static, device, "Valid")
        test_metrics = test(model, loaders[2], static, device, "Test")
        print(f"Epoch {epoch:04d} | {time.time()-start:.1f}s | loss={losses['total']:.4f} | "
              f"Valid {format_metrics(valid_metrics)} | Test {format_metrics(test_metrics)}")
        with open(metrics_path, "a", encoding="utf-8") as stream:
            stream.write(json.dumps({"epoch": epoch, "losses": losses, "valid": valid_metrics,
                                     "test": test_metrics, "seconds": time.time() - start}) + "\n")
        if valid_metrics["mse"] < best_mse:
            best_mse = valid_metrics["mse"]
            torch.save({"epoch": epoch, "model_state_dict": model.state_dict(), "args": vars(args),
                        "valid_metrics": valid_metrics, "test_metrics": test_metrics}, best_path)
        if args.dry_run:
            break
    print(f"best_model={best_path}")
    print(f"metrics={metrics_path}")


if __name__ == "__main__":
    main()
