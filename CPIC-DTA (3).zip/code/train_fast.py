"""Fast training schedule for the unchanged CPIC-DTA architecture."""

# NEW MODULE - encoders run once per epoch, predictors run per DTA mini-batch.

from __future__ import annotations

import os
import time
from datetime import datetime
from pathlib import Path

import torch
import torch.nn.functional as F

from data_process import load_data, process_data
from embedding_cache import EpochEmbeddingCache
from models import FastCPICDTA, affinity_aware_supcon_loss, binding_range_labels, censored_affinity_loss
from train_cpic import build_arg_parser, load_graph_batches, safe_torch_load, save_checkpoint, set_seed
from utils import collate, evaluate_regression, format_metrics, metric_is_better


def make_model(args, affinity_input_dim, device):
    return FastCPICDTA(
        tau=args.tau,
        lam=args.lam,
        ns_dims=[affinity_input_dim, 512, 256],
        drug_dims=[78, 128, 256],
        target_dims=[54, 128, 256],
        embedding_dim=128,
        edge_dropout_rate=args.edge_dropout_rate,
        max_drug_tokens=args.max_drug_tokens,
        max_target_tokens=args.max_target_tokens,
        pair_heads=args.pair_heads,
        pair_dropout=args.pair_dropout,
    ).to(device)


def pair_losses(args, pred, range_logits, pair_repr, data):
    y = data.y.view(-1).float().to(pred.device)
    if args.use_censored_loss and args.dataset == "davis":
        affinity_loss = censored_affinity_loss(
            pred, y, args.censored_value, args.censored_margin, args.censored_weight
        )
    else:
        affinity_loss = F.mse_loss(pred.view(-1), y)
    range_y = binding_range_labels(
        y, args.dataset, args.censored_value, args.range_low, args.range_high
    )
    range_loss = F.cross_entropy(range_logits, range_y)
    pair_contrast = affinity_aware_supcon_loss(
        pair_repr, y, args.pair_contrast_tau, args.pair_contrast_sigma
    )
    total = affinity_loss + args.range_loss_weight * range_loss + \
        args.pair_contrast_weight * pair_contrast
    return total, {"reg": affinity_loss, "range": range_loss, "pair_contrast": pair_contrast}


def static_losses(args, cache):
    aux = cache.auxiliary
    view_loss = F.mse_loss(aux["drug_relation_emb"], aux["drug_graph_emb"]) + \
        F.mse_loss(aux["target_relation_emb"], aux["target_graph_emb"])
    total = args.ssl_weight * aux["ssl_loss"] + args.view_mse_weight * view_loss
    return total, {"ssl": aux["ssl_loss"], "view": view_loss}


def train_epoch_fast(args, model, optimizer, loader, static_inputs, device, max_batches=None):
    """One differentiable entity encoding pass and one optimizer update per epoch."""
    model.train()
    optimizer.zero_grad(set_to_none=True)
    cache = EpochEmbeddingCache.build(model, *static_inputs)
    static_total, static_detail = static_losses(args, cache)
    sample_total = len(loader.dataset) if max_batches is None else min(len(loader.dataset), args.batch_size * max_batches)
    sums = {"reg": 0.0, "range": 0.0, "pair_contrast": 0.0}
    seen = 0
    batches = len(loader) if max_batches is None else min(len(loader), max_batches)

    for batch_index, data in enumerate(loader):
        if batch_index >= batches:
            break
        data = data.to(device, non_blocking=True)
        pred, range_logits, pair_repr = model.predict_from_cache(data, cache)
        pair_total, detail = pair_losses(args, pred, range_logits, pair_repr, data)
        batch_size = data.y.numel()
        seen += batch_size
        is_last = batch_index + 1 == batches
        objective = pair_total * (batch_size / max(sample_total, 1))
        if is_last:
            objective = objective + static_total
        objective.backward(retain_graph=not is_last)
        for key, value in detail.items():
            sums[key] += float(value.detach().cpu()) * batch_size

    torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
    optimizer.step()
    result = {key: value / max(seen, 1) for key, value in sums.items()}
    result.update({key: float(value.detach().cpu()) for key, value in static_detail.items()})
    result["total"] = result["reg"] + args.range_loss_weight * result["range"] + \
        args.pair_contrast_weight * result["pair_contrast"] + args.ssl_weight * result["ssl"] + \
        args.view_mse_weight * result["view"]
    return result


@torch.no_grad()
def predict_fast(model, loader, static_inputs, device, max_batches=None):
    model.eval()
    cache = EpochEmbeddingCache.build(model, *static_inputs).detached()
    labels, predictions = [], []
    for batch_index, data in enumerate(loader):
        if max_batches is not None and batch_index >= max_batches:
            break
        data = data.to(device, non_blocking=True)
        pred, _, _ = model.predict_from_cache(data, cache)
        labels.append(data.y.view(-1).cpu())
        predictions.append(pred.view(-1).cpu())
    y = torch.cat(labels).numpy()
    p = torch.cat(predictions).numpy()
    return y, p, evaluate_regression(y, p)


def main():
    parser = build_arg_parser()
    parser.description = "Fast training schedule for unchanged CPIC-DTA."
    parser.add_argument("--freeze_esm", action="store_true", default=True,
                        help="Compatibility flag; baseline CPIC has no ESM and never calls it.")
    parser.add_argument("--max_batches", type=int, default=None,
                        help="Optional debugging limit; use 1 with --epochs 1 for a quick smoke test.")
    args = parser.parse_args()
    if args.dataset == "kiba":
        args.num_pos = 10 if args.num_pos == 3 else args.num_pos
        args.edge_dropout_rate = 0.0 if args.edge_dropout_rate == 0.2 else args.edge_dropout_rate

    set_seed(args.seed)
    os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
    device = torch.device(f"cuda:{args.cuda}" if torch.cuda.is_available() else "cpu")
    result_dir = Path(args.result_dir) / args.dataset
    result_dir.mkdir(parents=True, exist_ok=True)
    log_path = result_dir / f"train_fast_{args.dataset}_{datetime.now():%Y%m%d_%H%M%S}.log"

    def log(message):
        print(message, flush=True)
        with open(log_path, "a", encoding="utf-8") as stream:
            stream.write(message + "\n")

    affinity = load_data(args.dataset, args.data_root)
    train_data, valid_data, test_data, affinity_graph, drug_pos, target_pos = process_data(
        affinity, args.dataset, args.data_root, args.feature_dir, args.num_pos, args.pos_threshold,
        args.valid_ratio, args.seed, args.filter_censored, args.censored_value,
    )
    loader_kwargs = dict(collate_fn=collate, pin_memory=device.type == "cuda")
    train_loader = torch.utils.data.DataLoader(train_data, batch_size=args.batch_size, shuffle=True, **loader_kwargs)
    valid_loader = torch.utils.data.DataLoader(valid_data, batch_size=args.batch_size, shuffle=False, **loader_kwargs)
    test_loader = torch.utils.data.DataLoader(test_data, batch_size=args.batch_size, shuffle=False, **loader_kwargs)

    affinity_graph = affinity_graph.to(device)
    drug_pos, target_pos = drug_pos.to(device), target_pos.to(device)
    drug_batch, target_batch = load_graph_batches(args, affinity_graph, device)
    static_inputs = (affinity_graph, drug_batch, target_batch, drug_pos, target_pos)
    model = make_model(args, affinity_graph.x.size(1), device)
    optimizer = torch.optim.Adam(
        (parameter for parameter in model.parameters() if parameter.requires_grad),
        lr=args.lr, weight_decay=args.weight_decay,
    )

    log(f"Fast CPIC-DTA | dataset={args.dataset} | device={device} | freeze_esm={args.freeze_esm}")
    log("Schedule: encode all entities once/epoch -> index cached embeddings per DTA batch -> one optimizer step")
    best, best_path = None, result_dir / "best_model.pt"
    for epoch in range(1, args.epochs + 1):
        started = time.perf_counter()
        losses = train_epoch_fast(args, model, optimizer, train_loader, static_inputs, device, args.max_batches)
        _, _, valid_metrics = predict_fast(model, valid_loader, static_inputs, device, args.max_batches)
        epoch_seconds = time.perf_counter() - started
        log(f"Epoch {epoch:04d} | {epoch_seconds:.2f}s | loss={losses['total']:.4f} | Valid {format_metrics(valid_metrics)}")
        if metric_is_better(valid_metrics, best, args.monitor):
            best = dict(valid_metrics)
            _, _, test_metrics = predict_fast(model, test_loader, static_inputs, device, args.max_batches)
            save_checkpoint(best_path, args, model, epoch, valid_metrics, test_metrics)
            log(f"  saved {best_path} | Test {format_metrics(test_metrics)}")

    checkpoint = safe_torch_load(best_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    _, _, final_test = predict_fast(model, test_loader, static_inputs, device, args.max_batches)
    log(f"Final Test {format_metrics(final_test)}")


if __name__ == "__main__":
    main()
