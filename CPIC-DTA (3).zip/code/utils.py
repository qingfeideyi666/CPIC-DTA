import math

# ORIGINAL MODULE MODIFIED: regression metrics now serve EHAM-CSCoDTA as well.
from typing import Dict, Optional

import numpy as np
import torch
from torch_geometric import data as DATA
from torch_geometric.data import Batch, InMemoryDataset


class DTADataset(InMemoryDataset):
    def __init__(self, root="/tmp", transform=None, pre_transform=None, drug_ids=None, target_ids=None, y=None):
        super().__init__(root, transform, pre_transform)
        self.process(drug_ids, target_ids, y)

    @property
    def raw_file_names(self):
        return []

    @property
    def processed_file_names(self):
        return []

    def download(self):
        pass

    def _download(self):
        pass

    def _process(self):
        pass

    def process(self, drug_ids, target_ids, y):
        data_list = []
        for i in range(len(drug_ids)):
            data_list.append(
                DATA.Data(
                    drug_id=torch.LongTensor([int(drug_ids[i])]),
                    target_id=torch.LongTensor([int(target_ids[i])]),
                    y=torch.FloatTensor([float(y[i])]),
                )
            )
        self._data = data_list

    def __len__(self):
        return len(self._data)

    def __getitem__(self, idx):
        return self._data[idx]


class GraphDataset(InMemoryDataset):
    def __init__(self, root="/tmp", transform=None, pre_transform=None, graphs_dict=None, dttype=None):
        super().__init__(root, transform, pre_transform)
        self.dttype = dttype
        self.process(graphs_dict)

    @property
    def raw_file_names(self):
        return []

    @property
    def processed_file_names(self):
        return []

    def download(self):
        pass

    def _download(self):
        pass

    def _process(self):
        pass

    def process(self, graphs_dict):
        data_list = []
        for key in graphs_dict:
            size, features, edge_index = graphs_dict[key]
            edge_index = np.asarray(edge_index)
            if edge_index.size == 0:
                edge_index = np.zeros((2, 0), dtype=np.int64)
            elif edge_index.shape[0] != 2:
                edge_index = edge_index.T
            graph = DATA.Data(
                x=torch.as_tensor(np.asarray(features, dtype=np.float32)),
                edge_index=torch.LongTensor(edge_index),
            )
            graph.__setitem__(f"{self.dttype}_size", torch.LongTensor([int(size)]))
            data_list.append(graph)
        self._data = data_list

    def __len__(self):
        return len(self._data)

    def __getitem__(self, idx):
        return self._data[idx]


def collate(data_list):
    return Batch.from_data_list(data_list)


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse_coo_tensor(indices, values, shape)


def min_max_normalize(y, y_min=None, y_max=None):
    y = np.asarray(y, dtype=np.float32)
    if y_min is None:
        y_min = np.nanmin(y)
    if y_max is None:
        y_max = np.nanmax(y)
    denom = y_max - y_min
    if abs(denom) < 1e-12:
        return np.zeros_like(y)
    return (y - y_min) / denom


def dense_affinity_refine(adj, k):
    adj = np.asarray(adj)
    k = int(min(k, adj.shape[1]))
    refine_adj = np.zeros_like(adj)
    row_ids = np.tile(np.expand_dims(np.arange(adj.shape[0]), 0), (k, 1)).T
    col_ids = np.argpartition(adj, -k, 1)[:, -k:]
    refine_adj[row_ids, col_ids] = adj[row_ids, col_ids]
    return refine_adj


def get_mse(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    return float(np.mean((y_true - y_pred) ** 2))


def get_rmse(y_true, y_pred):
    return float(math.sqrt(get_mse(y_true, y_pred)))


def get_pearson(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    if y_true.size < 2 or np.std(y_true) < 1e-12 or np.std(y_pred) < 1e-12:
        return 0.0
    return float(np.corrcoef(y_true, y_pred)[0, 1])


def _rankdata(a):
    a = np.asarray(a)
    sorter = np.argsort(a, kind="mergesort")
    inv = np.empty_like(sorter)
    inv[sorter] = np.arange(len(a))
    sorted_a = a[sorter]
    obs = np.r_[True, sorted_a[1:] != sorted_a[:-1]]
    dense = obs.cumsum()
    count = np.r_[np.nonzero(obs)[0], len(a)]
    ranks = np.zeros(len(a), dtype=np.float64)
    for i in range(len(count) - 1):
        start, end = count[i], count[i + 1]
        ranks[start:end] = 0.5 * (start + end - 1) + 1
    return ranks[inv]


def get_spearman(y_true, y_pred):
    return get_pearson(_rankdata(y_true), _rankdata(y_pred))


def get_ci(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    order = np.argsort(y_true)
    y_true = y_true[order]
    y_pred = y_pred[order]
    concordant = 0.0
    comparable = 0.0
    n = len(y_true)
    for i in range(n - 1):
        diff_true = y_true[i + 1 :] - y_true[i]
        mask = diff_true > 0
        if not np.any(mask):
            continue
        diff_pred = y_pred[i + 1 :][mask] - y_pred[i]
        comparable += diff_pred.size
        concordant += np.sum(diff_pred > 0) + 0.5 * np.sum(diff_pred == 0)
    if comparable == 0:
        return 0.0
    return float(concordant / comparable)


def r_squared_error(y_obs, y_pred):
    y_obs = np.asarray(y_obs, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    y_obs_mean = np.mean(y_obs)
    y_pred_mean = np.mean(y_pred)
    numerator = np.sum((y_obs - y_obs_mean) * (y_pred - y_pred_mean)) ** 2
    denominator = np.sum((y_obs - y_obs_mean) ** 2) * np.sum((y_pred - y_pred_mean) ** 2)
    if denominator < 1e-12:
        return 0.0
    return float(numerator / denominator)


def get_k(y_obs, y_pred):
    y_obs = np.asarray(y_obs, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    denom = np.sum(y_pred ** 2)
    if denom < 1e-12:
        return 0.0
    return float(np.sum(y_obs * y_pred) / denom)


def squared_error_zero(y_obs, y_pred):
    k = get_k(y_obs, y_pred)
    y_obs = np.asarray(y_obs, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    y_obs_mean = np.mean(y_obs)
    numerator = np.sum((y_obs - k * y_pred) ** 2)
    denominator = np.sum((y_obs - y_obs_mean) ** 2)
    if denominator < 1e-12:
        return 0.0
    return float(1 - numerator / denominator)


def get_rm2(y_true, y_pred):
    r2 = r_squared_error(y_true, y_pred)
    r02 = squared_error_zero(y_true, y_pred)
    return float(r2 * (1 - np.sqrt(np.absolute(r2**2 - r02**2))))


def evaluate_regression(y_true, y_pred) -> Dict[str, float]:
    return {
        "mse": get_mse(y_true, y_pred),
        "rmse": get_rmse(y_true, y_pred),
        "ci": get_ci(y_true, y_pred),
        "rm2": get_rm2(y_true, y_pred),
        "pearson": get_pearson(y_true, y_pred),
        "spearman": get_spearman(y_true, y_pred),
    }


def format_metrics(metrics: Dict[str, float]) -> str:
    keys = ["mse", "rmse", "ci", "rm2", "pearson", "spearman"]
    labels = {"ci": "CI/Concordance Index"}
    return " | ".join(f"{labels.get(k, k.upper())}: {metrics[k]:.4f}" for k in keys if k in metrics)


def metric_is_better(current: Dict[str, float], best: Optional[Dict[str, float]], monitor: str) -> bool:
    if best is None:
        return True
    if monitor in {"mse", "rmse"}:
        return current[monitor] < best[monitor]
    return current[monitor] > best[monitor]
